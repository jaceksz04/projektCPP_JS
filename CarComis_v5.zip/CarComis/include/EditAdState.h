#pragma once
#include "IState.h"
#include "AppContext.h"
#include "UIHelper.h"
#include "Car.h"
#include <array>
#include <string>
#include <vector>

class EditAdState : public IState {
public:
    EditAdState(AppContext& ctx, const Car& car);

    void handleEvent(sf::Event& event, StateManager& sm) override;
    void update(float dt, StateManager& sm) override {}
    void render(sf::RenderWindow& window) override;

private:
    AppContext& m_ctx;
    int         m_carId;   // ID edytowanego auta

    static constexpr int FIELD_COUNT = 6;
    std::array<UI::InputField, FIELD_COUNT> m_fields;
    int m_focused = 0;

    std::string              m_mainImage;
    std::vector<std::string> m_extraImages;
    sf::Texture m_previewTex;
    bool        m_previewLoaded = false;

    static const std::vector<std::string> FUEL_OPTIONS;
    static const std::vector<std::string> BODY_OPTIONS;
    int m_selectedFuel = -1;
    int m_selectedBody = -1;

    sf::FloatRect m_btnSave;
    sf::FloatRect m_btnBack;
    sf::FloatRect m_btnPickMain;
    sf::FloatRect m_btnPickExtra;
    sf::FloatRect m_btnClearExtra;

    std::vector<sf::FloatRect> m_btnFuel;
    std::vector<sf::FloatRect> m_btnBody;

    std::string m_message;

    void recalcLayout();
    void save(StateManager& sm);
    void pickMainImage();
    void pickExtraImages();
    void drawOptionRow(sf::RenderWindow& window, const std::string& label,
                       const std::vector<std::string>& options,
                       std::vector<sf::FloatRect>& rects,
                       int selected, float x, float y, float W, float H);
};
