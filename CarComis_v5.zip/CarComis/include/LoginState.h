#pragma once
#include "IState.h"
#include "AppContext.h"
#include "UIHelper.h"

class LoginState : public IState {
public:
    explicit LoginState(AppContext& ctx);

    void handleEvent(sf::Event& event, StateManager& sm) override;
    void update(float dt, StateManager& sm) override {}
    void render(sf::RenderWindow& window) override;

private:
    AppContext& m_ctx;

    UI::InputField m_fieldLogin;
    UI::InputField m_fieldPassword;
    int            m_focused = 0;

    sf::FloatRect m_btnLogin;
    sf::FloatRect m_btnBack;

    std::string m_errorMsg;

    static constexpr const char* SELLER_LOGIN    = "sprzedawca";
    static constexpr const char* SELLER_PASSWORD = "komis123";

    void recalcLayout();
    void tryLogin(StateManager& sm);
};
