#pragma once
#include "IState.h"
#include "AppContext.h"
#include "UIHelper.h"
#include "Car.h"
#include <vector>
#include <string>

class DetailState : public IState {
public:
    DetailState(AppContext& ctx, const Car& car)
        : m_ctx(ctx), m_car(car) {
        if (!car.imagePath.empty()) m_allImages.push_back(car.imagePath);
        for (const auto& p : car.extraImages) m_allImages.push_back(p);
        recalcLayout();
    }

    void handleEvent(sf::Event& event, StateManager& sm) override;
    void update(float dt, StateManager& sm) override {}
    void render(sf::RenderWindow& window) override;

private:
    AppContext& m_ctx;
    Car         m_car;

    std::vector<std::string>   m_allImages;
    int  m_thumbSelected  = 0;
    int  m_thumbScrollOff = 0;   // offset przewijania miniaturek
    bool m_lightboxOpen   = false;
    int  m_lightboxIdx    = 0;

    sf::FloatRect m_mainImgRect;
    std::vector<sf::FloatRect> m_thumbRects;
    sf::FloatRect m_btnThumbPrev;
    sf::FloatRect m_btnThumbNext;

    sf::FloatRect m_lbBtnPrev;
    sf::FloatRect m_lbBtnNext;
    sf::FloatRect m_lbBtnClose;

    sf::FloatRect m_btnBack;
    sf::FloatRect m_btnDelete;
    sf::FloatRect m_btnWatch;
    sf::FloatRect m_btnEdit;

    bool m_deleted = false;
    std::string m_message;

    void recalcLayout();
    void drawGallery(sf::RenderWindow& window);
    void drawLightbox(sf::RenderWindow& window);
};
