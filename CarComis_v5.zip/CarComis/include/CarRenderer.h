#pragma once
#include <SFML/Graphics.hpp>
#include "Car.h"
#include <unordered_map>
#include <string>

class CarRenderer {
public:
    explicit CarRenderer(sf::Font& font);

    void drawCard(sf::RenderWindow& window, const Car& car,
                  const sf::FloatRect& bounds, bool selected = false);

    void drawDetail(sf::RenderWindow& window, const Car& car,
                    const sf::FloatRect& bounds);

    // Publiczne � uzywane przez DetailState (lightbox, miniaturki)
    void drawImage(sf::RenderWindow& window, const std::string& path,
                   const sf::FloatRect& rect, bool drawBorder = false);

    sf::Texture& getTexture(const std::string& path);

private:
    sf::Font&                                    m_font;
    std::unordered_map<std::string, sf::Texture> m_textureCache;

    sf::Texture& getOrLoadTexture(const std::string& path);
    void         drawPlaceholder(sf::RenderWindow& window, const sf::FloatRect& rect);
};
