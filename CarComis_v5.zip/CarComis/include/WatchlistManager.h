#pragma once
#include <set>
#include <string>
#include <fstream>
#include <sstream>

// SRP: odpowiada wylacznie za zarzadzanie lista obserwowanych (zapis/odczyt/toggle)
class WatchlistManager {
public:
    explicit WatchlistManager(const std::string& filePath = "data/watchlist.txt")
        : m_filePath(filePath) { load(); }

    void toggle(int id) {
        if (m_ids.count(id)) m_ids.erase(id);
        else                  m_ids.insert(id);
        save();
    }

    bool contains(int id) const { return m_ids.count(id) > 0; }
    bool empty()          const { return m_ids.empty(); }

    const std::set<int>& ids() const { return m_ids; }

private:
    std::string  m_filePath;
    std::set<int> m_ids;

    void load() {
        std::ifstream f(m_filePath);
        if (!f.is_open()) return;
        int id;
        while (f >> id) m_ids.insert(id);
    }

    void save() const {
        std::ofstream f(m_filePath);
        for (int id : m_ids) f << id << "\n";
    }
};
