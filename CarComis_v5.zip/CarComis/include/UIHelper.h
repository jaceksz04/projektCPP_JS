#pragma once
#include <SFML/Graphics.hpp>
#include <string>
#include <vector>
#ifdef _WIN32
#include <windows.h>
#include <commdlg.h>
#endif

namespace UI {

// ── Konwersja UTF-8 <-> szerokie znaki (Windows) ─────────────────────────────
inline std::string wstrToUtf8(const std::wstring& w) {
#ifdef _WIN32
    if (w.empty()) return {};
    int sz = WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(),
                                  nullptr, 0, nullptr, nullptr);
    std::string s(sz, 0);
    WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(),
                         s.data(), sz, nullptr, nullptr);
    return s;
#else
    return std::string(w.begin(), w.end());
#endif
}

inline std::wstring utf8ToWstr(const std::string& s) {
#ifdef _WIN32
    if (s.empty()) return {};
    int sz = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0);
    std::wstring w(sz, 0);
    MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), w.data(), sz);
    return w;
#else
    return std::wstring(s.begin(), s.end());
#endif
}

// Konwertuje UTF-8 std::string → sf::String (obsługuje polskie znaki w sf::Text)
inline sf::String toSfStr(const std::string& utf8) {
#ifdef _WIN32
    // Na Windows literały są UTF-8 (jeśli plik zapisany w UTF-8).
    // Konwertujemy UTF-8 → UTF-16 (wstring) → sf::String.
    std::wstring w = utf8ToWstr(utf8);
    return sf::String(w);
#else
    return sf::String::fromUtf8(utf8.begin(), utf8.end());
#endif
}

// SFML przesyła znaki jako Unicode code pointy (sf::Event::TextEntered).
// Ta funkcja konwertuje pojedynczy code point na UTF-8 string.
inline std::string codepointToUtf8(sf::Uint32 cp) {
    std::string out;
    if (cp < 0x80) {
        out += static_cast<char>(cp);
    } else if (cp < 0x800) {
        out += static_cast<char>(0xC0 | (cp >> 6));
        out += static_cast<char>(0x80 | (cp & 0x3F));
    } else if (cp < 0x10000) {
        out += static_cast<char>(0xE0 | (cp >> 12));
        out += static_cast<char>(0x80 | ((cp >> 6) & 0x3F));
        out += static_cast<char>(0x80 | (cp & 0x3F));
    }
    return out;
}

// ── Okno dialogowe wyboru pliku (Windows) ────────────────────────────────────
inline std::string openFileDialog(const std::string& title = "Wybierz zdjecie",
                                   const std::string& filter = "Obrazy\0*.jpg;*.jpeg;*.png;*.bmp\0Wszystkie pliki\0*.*\0") {
#ifdef _WIN32
    wchar_t buf[MAX_PATH] = {};
    OPENFILENAMEW ofn = {};
    ofn.lStructSize  = sizeof(ofn);
    ofn.hwndOwner    = nullptr;
    ofn.lpstrFile    = buf;
    ofn.nMaxFile     = MAX_PATH;
    std::wstring wfilter;
    for (size_t i = 0; i < filter.size(); ++i)
        wfilter += static_cast<wchar_t>(static_cast<unsigned char>(filter[i]));
    ofn.lpstrFilter  = wfilter.c_str();
    std::wstring wtitle = utf8ToWstr(title);
    ofn.lpstrTitle   = wtitle.c_str();
    ofn.Flags        = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
    if (GetOpenFileNameW(&ofn)) return wstrToUtf8(buf);
    return {};
#else
    return {};
#endif
}

// Multi-select: zwraca wektor sciezek (Windows OFN_ALLOWMULTISELECT)
inline std::vector<std::string> openFileDialogMulti(
        const std::string& title  = "Wybierz zdjecia",
        const std::string& filter = "Obrazy\0*.jpg;*.jpeg;*.png;*.bmp\0Wszystkie pliki\0*.*\0") {
    std::vector<std::string> result;
#ifdef _WIN32
    // Bufor musi byc duzy – sciezki wielu plikow sa rozdzielone \0
    const int BUF = 32768;
    std::vector<wchar_t> buf(BUF, 0);
    OPENFILENAMEW ofn = {};
    ofn.lStructSize = sizeof(ofn);
    ofn.lpstrFile   = buf.data();
    ofn.nMaxFile    = BUF;
    std::wstring wfilter;
    for (size_t i = 0; i < filter.size(); ++i)
        wfilter += static_cast<wchar_t>(static_cast<unsigned char>(filter[i]));
    ofn.lpstrFilter = wfilter.c_str();
    std::wstring wtitle = utf8ToWstr(title);
    ofn.lpstrTitle  = wtitle.c_str();
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST |
                OFN_NOCHANGEDIR   | OFN_ALLOWMULTISELECT | OFN_EXPLORER;
    if (!GetOpenFileNameW(&ofn)) return result;

    // Parsowanie: jesli wybrano 1 plik -> buf zawiera pelna sciezke
    // jesli wiele -> katalog\0plik1\0plik2\0\0
    wchar_t* p = buf.data();
    std::wstring dir = p;
    p += dir.size() + 1;
    if (*p == L'\0') {
        // Jeden plik
        result.push_back(wstrToUtf8(dir));
    } else {
        // Wiele plikow
        while (*p) {
            std::wstring fname = p;
            result.push_back(wstrToUtf8(dir + L"\\" + fname));
            p += fname.size() + 1;
        }
    }
#endif
    return result;
}

// ── Geometria responsywna ─────────────────────────────────────────────────────
// Zwraca prostokąt jako % wymiarów okna
inline sf::FloatRect pct(const sf::RenderWindow& w,
                          float xPct, float yPct,
                          float wPct, float hPct) {
    float W = static_cast<float>(w.getSize().x);
    float H = static_cast<float>(w.getSize().y);
    return { xPct * W, yPct * H, wPct * W, hPct * H };
}

// ── Rysowanie przycisku ───────────────────────────────────────────────────────
inline void drawButton(sf::RenderWindow& window, sf::Font& font,
                        const sf::FloatRect& rect, const std::string& label,
                        bool hovered = false, bool active = false) {
    sf::RectangleShape btn(sf::Vector2f(rect.width, rect.height));
    btn.setPosition(rect.left, rect.top);

    if (active)       btn.setFillColor(sf::Color(50, 120, 200));
    else if (hovered) btn.setFillColor(sf::Color(60, 70, 100));
    else              btn.setFillColor(sf::Color(40, 45, 65));

    btn.setOutlineThickness(1.f);
    btn.setOutlineColor(active ? sf::Color(100, 180, 255) : sf::Color(80, 80, 110));
    window.draw(btn);

    unsigned charSz = static_cast<unsigned>(std::max(10.f, rect.height * 0.45f));
    sf::Text txt(toSfStr(label), font, charSz);
    txt.setFillColor(sf::Color(220, 220, 240));
    sf::FloatRect tb = txt.getLocalBounds();
    txt.setPosition(rect.left + (rect.width  - tb.width)  * 0.5f - tb.left,
                    rect.top  + (rect.height - tb.height) * 0.5f - tb.top);
    window.draw(txt);
}

inline bool isHovered(const sf::FloatRect& rect, sf::RenderWindow& window) {
    auto mp = sf::Mouse::getPosition(window);
    return rect.contains(static_cast<float>(mp.x), static_cast<float>(mp.y));
}

// ── Pole tekstowe z obsługą UTF-8 ─────────────────────────────────────────────
struct InputField {
    sf::FloatRect bounds;
    std::string   label;
    std::string   value;   // przechowuje UTF-8
    bool          focused = false;
    bool          passwordMode = false;  // maskowanie gwiazdkami

    void draw(sf::RenderWindow& window, sf::Font& font) const {
        sf::RectangleShape bg(sf::Vector2f(bounds.width, bounds.height));
        bg.setPosition(bounds.left, bounds.top);
        bg.setFillColor(sf::Color(20, 20, 30));
        bg.setOutlineThickness(focused ? 2.f : 1.f);
        bg.setOutlineColor(focused ? sf::Color(80, 150, 255) : sf::Color(70, 70, 100));
        window.draw(bg);

        unsigned lblSz = static_cast<unsigned>(std::max(10.f, bounds.height * 0.5f));
        sf::Text lbl(toSfStr(label + ":"), font, lblSz);
        lbl.setFillColor(sf::Color(160, 160, 200));
        lbl.setPosition(bounds.left, bounds.top - lblSz - 2);
        window.draw(lbl);

        std::string display = passwordMode
            ? std::string(value.size(), '*')   // uproszczone – bajty, nie code pointy
            : value;
        if (focused) display += '|';

        sf::Text val(toSfStr(display), font, lblSz);
        val.setFillColor(sf::Color(230, 230, 250));
        val.setPosition(bounds.left + 6,
                        bounds.top + (bounds.height - lblSz) * 0.5f);
        window.draw(val);
    }

    void handleEvent(const sf::Event& e) {
        if (!focused) return;
        if (e.type == sf::Event::TextEntered) {
            if (e.text.unicode == 8) {
                // Backspace – usuń ostatni znak UTF-8
                if (!value.empty()) {
                    // Cofaj po bajcie aż do początku znaku
                    size_t i = value.size() - 1;
                    while (i > 0 && (value[i] & 0xC0) == 0x80) --i;
                    value.erase(i);
                }
            } else if (e.text.unicode >= 32) {
                value += codepointToUtf8(e.text.unicode);
            }
        }
    }
};

} // namespace UI
