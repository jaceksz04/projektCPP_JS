#pragma once
#include <SFML/Graphics.hpp>
#include <memory>
#include "CarInventory.h"
#include "CarRenderer.h"
#include "User.h"
#include "WatchlistManager.h"

struct AppContext {
    sf::RenderWindow& window;
    sf::Font&         font;
    CarInventory&     inventory;
    CarRenderer&      renderer;
    User&             currentUser;
    WatchlistManager& watchlist;
};
