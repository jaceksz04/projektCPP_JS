#include "MenuState.h"
#include "GalleryState.h"
#include "LoginState.h"

void MenuState::handleEvent(sf::Event& event, StateManager& sm) {
    if (event.type == sf::Event::MouseButtonPressed &&
        event.mouseButton.button == sf::Mouse::Left) {

        float W = static_cast<float>(m_ctx.window.getSize().x);
        float H = static_cast<float>(m_ctx.window.getSize().y);
        sf::FloatRect btnBuyer  { W*0.30f, H*0.42f, W*0.40f, H*0.09f };
        sf::FloatRect btnSeller { W*0.30f, H*0.55f, W*0.40f, H*0.09f };

        auto mp = sf::Vector2f(static_cast<float>(event.mouseButton.x),
                               static_cast<float>(event.mouseButton.y));

        if (btnBuyer.contains(mp)) {
            m_ctx.currentUser = {"Kupujący", UserRole::Buyer};
            sm.replaceDeferred(std::make_shared<GalleryState>(m_ctx));
        } else if (btnSeller.contains(mp)) {
            sm.replaceDeferred(std::make_shared<LoginState>(m_ctx));
        }
    }
}

void MenuState::render(sf::RenderWindow& window) {
    window.clear(sf::Color(15, 15, 25));

    float W = static_cast<float>(window.getSize().x);
    float H = static_cast<float>(window.getSize().y);

    // Tlo gradientowe
    sf::RectangleShape bg1(sf::Vector2f(W, H * 0.5f));
    bg1.setFillColor(sf::Color(15, 15, 30));
    window.draw(bg1);
    sf::RectangleShape bg2(sf::Vector2f(W, H * 0.5f));
    bg2.setPosition(0, H * 0.5f);
    bg2.setFillColor(sf::Color(10, 10, 20));
    window.draw(bg2);

    float titleY = H * 0.17f;

    // Tytul (wycentrowany idealnie na srodku ekranu)
    unsigned titleSz = static_cast<unsigned>(H * 0.068f);
    sf::Text title(UI::toSfStr("Komis Samochodowy"), m_ctx.font, titleSz);
    title.setFillColor(sf::Color(80, 160, 255));
    sf::FloatRect tb = title.getLocalBounds();
    float textX = W * 0.5f - tb.width * 0.5f;
    title.setPosition(textX, titleY - tb.top);
    window.draw(title);

    // Podtytul
    unsigned subSz = static_cast<unsigned>(H * 0.032f);
    sf::Text sub(UI::toSfStr("System zarządzania ogłoszeniami"), m_ctx.font, subSz);
    sub.setFillColor(sf::Color(120, 120, 160));
    sf::FloatRect sb = sub.getLocalBounds();
    sub.setPosition(W * 0.5f - sb.width * 0.5f, H * 0.30f);
    window.draw(sub);

    // Przyciski
    auto mp = sf::Mouse::getPosition(window);
    sf::Vector2f mf(static_cast<float>(mp.x), static_cast<float>(mp.y));

    sf::FloatRect btnBuyer  { W*0.30f, H*0.42f, W*0.40f, H*0.09f };
    sf::FloatRect btnSeller { W*0.30f, H*0.55f, W*0.40f, H*0.09f };

    UI::drawButton(window, m_ctx.font, btnBuyer,
                   "Przeglądaj oferty", btnBuyer.contains(mf));
    UI::drawButton(window, m_ctx.font, btnSeller,
                   "Zaloguj jako Sprzedawca", btnSeller.contains(mf));

    unsigned descSz = static_cast<unsigned>(H * 0.024f);
    sf::Text d1(UI::toSfStr("Szukaj i filtruj ogłoszenia samochodów"), m_ctx.font, descSz);
    d1.setFillColor(sf::Color(80, 80, 110));
    sf::FloatRect d1b = d1.getLocalBounds();
    d1.setPosition(W * 0.5f - d1b.width * 0.5f, H * 0.52f);
    window.draw(d1);

    sf::Text d2(UI::toSfStr("Dodawaj i zarządzaj ogłoszeniami"), m_ctx.font, descSz);
    d2.setFillColor(sf::Color(80, 80, 110));
    sf::FloatRect d2b = d2.getLocalBounds();
    d2.setPosition(W * 0.5f - d2b.width * 0.5f, H * 0.65f);
    window.draw(d2);
}
