#include "LoginState.h"
#include "GalleryState.h"
#include "MenuState.h"

LoginState::LoginState(AppContext& ctx) : m_ctx(ctx) {
    recalcLayout();
}

void LoginState::recalcLayout() {
    float W = static_cast<float>(m_ctx.window.getSize().x);
    float H = static_cast<float>(m_ctx.window.getSize().y);
    float cx = W * 0.5f;
    float fieldW = W * 0.32f;
    float fieldH = H * 0.055f;

    m_fieldLogin.bounds    = { cx - fieldW*0.5f, H*0.38f, fieldW, fieldH };
    m_fieldLogin.label     = "Login";
    m_fieldLogin.focused   = (m_focused == 0);

    m_fieldPassword.bounds       = { cx - fieldW*0.5f, H*0.52f, fieldW, fieldH };
    m_fieldPassword.label        = "Hasło";
    m_fieldPassword.passwordMode = true;
    m_fieldPassword.focused      = (m_focused == 1);

    m_btnLogin = { cx - fieldW*0.5f, H*0.64f, fieldW,     H*0.07f };
    m_btnBack  = { W*0.02f,          H*0.02f, W*0.10f,    H*0.05f };
}

void LoginState::tryLogin(StateManager& sm) {
    if (m_fieldLogin.value == SELLER_LOGIN &&
        m_fieldPassword.value == SELLER_PASSWORD) {
        m_ctx.currentUser = {"Sprzedawca", UserRole::Seller};
        sm.replaceDeferred(std::make_shared<GalleryState>(m_ctx));
    } else {
        m_errorMsg = "Nieprawidłowy login lub hasło!";
        m_fieldPassword.value = "";
    }
}

void LoginState::handleEvent(sf::Event& event, StateManager& sm) {
    if (event.type == sf::Event::Resized) recalcLayout();

    if (m_focused == 0) m_fieldLogin.handleEvent(event);
    else                m_fieldPassword.handleEvent(event);

    if (event.type == sf::Event::MouseButtonPressed &&
        event.mouseButton.button == sf::Mouse::Left) {

        sf::Vector2f mp(static_cast<float>(event.mouseButton.x),
                        static_cast<float>(event.mouseButton.y));

        if (m_btnBack.contains(mp))  { sm.replaceDeferred(std::make_shared<MenuState>(m_ctx)); return; }
        if (m_btnLogin.contains(mp)) { tryLogin(sm); return; }

        if (m_fieldLogin.bounds.contains(mp)) {
            m_focused = 0;
            m_fieldLogin.focused = true;
            m_fieldPassword.focused = false;
        }
        if (m_fieldPassword.bounds.contains(mp)) {
            m_focused = 1;
            m_fieldLogin.focused = false;
            m_fieldPassword.focused = true;
        }
    }

    if (event.type == sf::Event::KeyPressed) {
        if (event.key.code == sf::Keyboard::Tab) {
            m_focused = (m_focused + 1) % 2;
            m_fieldLogin.focused    = (m_focused == 0);
            m_fieldPassword.focused = (m_focused == 1);
        }
        if (event.key.code == sf::Keyboard::Return) {
            if (m_focused == 0) {
                m_focused = 1;
                m_fieldLogin.focused    = false;
                m_fieldPassword.focused = true;
            } else {
                tryLogin(sm);
            }
        }
    }
}

void LoginState::render(sf::RenderWindow& window) {
    recalcLayout();
    window.clear(sf::Color(15, 15, 25));

    float W = static_cast<float>(window.getSize().x);
    float H = static_cast<float>(window.getSize().y);

    // Panel
    float panW = W * 0.42f, panH = H * 0.55f;
    sf::RectangleShape panel(sf::Vector2f(panW, panH));
    panel.setPosition(W * 0.5f - panW * 0.5f, H * 0.22f);
    panel.setFillColor(sf::Color(22, 22, 35));
    panel.setOutlineThickness(1);
    panel.setOutlineColor(sf::Color(60, 80, 140));
    window.draw(panel);

    // Tytuł
    sf::Text title(UI::toSfStr("Logowanie — Sprzedawca"), m_ctx.font,
                   static_cast<unsigned>(H * 0.040f));
    title.setFillColor(sf::Color(80, 160, 255));
    sf::FloatRect tb = title.getLocalBounds();
    title.setPosition(W * 0.5f - tb.width * 0.5f, H * 0.26f);
    window.draw(title);

    sf::Text hint(UI::toSfStr("Login: sprzedawca   Hasło: komis123"), m_ctx.font,
                  static_cast<unsigned>(H * 0.020f));
    hint.setFillColor(sf::Color(70, 70, 100));
    sf::FloatRect hb = hint.getLocalBounds();
    hint.setPosition(W * 0.5f - hb.width * 0.5f, H * 0.32f);
    window.draw(hint);

    m_fieldLogin.draw(window, m_ctx.font);
    m_fieldPassword.draw(window, m_ctx.font);

    auto mp = sf::Vector2f(sf::Mouse::getPosition(window));
    UI::drawButton(window, m_ctx.font, m_btnLogin, "Zaloguj się", m_btnLogin.contains(mp));
    UI::drawButton(window, m_ctx.font, m_btnBack,  "< Wstecz",   m_btnBack.contains(mp));

    if (!m_errorMsg.empty()) {
        sf::Text err(UI::toSfStr(m_errorMsg), m_ctx.font, static_cast<unsigned>(H * 0.028f));
        err.setFillColor(sf::Color(220, 60, 60));
        sf::FloatRect eb = err.getLocalBounds();
        err.setPosition(W * 0.5f - eb.width * 0.5f, H * 0.73f);
        window.draw(err);
    }

    sf::Text tabHint(UI::toSfStr("Tab = następne pole  |  Enter = zatwierdź"), m_ctx.font,
                     static_cast<unsigned>(H * 0.020f));
    tabHint.setFillColor(sf::Color(70, 70, 100));
    sf::FloatRect thb = tabHint.getLocalBounds();
    tabHint.setPosition(W * 0.5f - thb.width * 0.5f, H * 0.78f);
    window.draw(tabHint);
}
