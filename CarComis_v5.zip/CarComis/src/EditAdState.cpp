#include "EditAdState.h"
#include "GalleryState.h"
#include <stdexcept>
#include <algorithm>

const std::vector<std::string> EditAdState::FUEL_OPTIONS = {
    "benzyna","diesel","elektryczny","hybryda"
};
const std::vector<std::string> EditAdState::BODY_OPTIONS = {
    "sedan","kombi","coupe","suv","hatchback"
};

EditAdState::EditAdState(AppContext& ctx, const Car& car)
    : m_ctx(ctx), m_carId(car.id) {

    std::array<std::string, FIELD_COUNT> labels = {
        "Marka","Model","Rok produkcji","Przebieg (km)","Cena (PLN)","Opis"
    };
    std::array<std::string, FIELD_COUNT> values = {
        car.brand, car.model,
        std::to_string(car.year), std::to_string(car.mileage),
        std::to_string((int)car.price), car.description
    };
    for (int i = 0; i < FIELD_COUNT; ++i) {
        m_fields[i].label   = labels[i];
        m_fields[i].value   = values[i];
        m_fields[i].focused = (i == 0);
    }

    m_mainImage   = car.imagePath;
    m_extraImages = car.extraImages;
    if (!m_mainImage.empty()) m_previewLoaded = m_previewTex.loadFromFile(m_mainImage);

    // Wstaw wybrane paliwo/nadwozie
    for (int i = 0; i < (int)FUEL_OPTIONS.size(); ++i)
        if (FUEL_OPTIONS[i] == car.fuelType) { m_selectedFuel = i; break; }
    for (int i = 0; i < (int)BODY_OPTIONS.size(); ++i)
        if (BODY_OPTIONS[i] == car.bodyType) { m_selectedBody = i; break; }

    m_btnFuel.assign(FUEL_OPTIONS.size(), sf::FloatRect{});
    m_btnBody.assign(BODY_OPTIONS.size(), sf::FloatRect{});
    recalcLayout();
}

void EditAdState::recalcLayout() {
    float W = static_cast<float>(m_ctx.window.getSize().x);
    float H = static_cast<float>(m_ctx.window.getSize().y);

    float formX  = W * 0.04f;
    float startY = H * 0.10f;
    float stepY  = H * 0.095f;
    float fieldW = W * 0.38f;
    float fieldH = H * 0.048f;

    for (int i = 0; i < FIELD_COUNT; ++i)
        m_fields[i].bounds = { formX, startY + i * stepY, fieldW, fieldH };

    float rightX  = W * 0.50f;
    float imgBtnW = W * 0.22f;
    float btnH    = H * 0.055f;

    m_btnPickMain   = { rightX,                       H*0.10f, imgBtnW,    btnH };
    m_btnPickExtra  = { rightX,                       H*0.19f, imgBtnW,    btnH };
    m_btnClearExtra = { rightX + imgBtnW + W*0.01f,   H*0.19f, W*0.09f,   btnH };

    m_btnSave = { W*0.36f, H*0.88f, W*0.14f, btnH };
    m_btnBack = { W*0.02f, H*0.02f, W*0.10f, H*0.05f };

    m_btnFuel.assign(FUEL_OPTIONS.size(), sf::FloatRect{});
    m_btnBody.assign(BODY_OPTIONS.size(), sf::FloatRect{});
}

void EditAdState::pickMainImage() {
    std::string path = UI::openFileDialog("Wybierz zdjecie glowne");
    if (!path.empty()) {
        m_mainImage     = path;
        m_previewLoaded = m_previewTex.loadFromFile(path);
    }
}

void EditAdState::pickExtraImages() {
    auto paths = UI::openFileDialogMulti("Wybierz dodatkowe zdjecia (max 10)");
    for (const auto& p : paths) {
        if (m_extraImages.size() >= 10) break;
        m_extraImages.push_back(p);
    }
}

void EditAdState::save(StateManager& sm) {
    try {
        if (m_fields[0].value.empty() || m_fields[1].value.empty())
            throw std::invalid_argument("Marka i model sa wymagane.");

        Car updated;
        updated.id          = m_carId;
        updated.brand       = m_fields[0].value;
        updated.model       = m_fields[1].value;
        updated.year        = std::stoi(m_fields[2].value);
        updated.mileage     = std::stoi(m_fields[3].value);
        updated.price       = std::stod(m_fields[4].value);
        updated.description = m_fields[5].value;
        updated.imagePath   = m_mainImage;
        updated.extraImages = m_extraImages;
        updated.fuelType    = (m_selectedFuel >= 0) ? FUEL_OPTIONS[m_selectedFuel] : "";
        updated.bodyType    = (m_selectedBody >= 0) ? BODY_OPTIONS[m_selectedBody] : "";

        m_ctx.inventory.updateCar(updated);
        m_ctx.inventory.save();
        sm.replaceDeferred(std::make_shared<GalleryState>(m_ctx));
    } catch (const std::exception& e) {
        m_message = std::string("Blad: ") + e.what();
    }
}

void EditAdState::drawOptionRow(sf::RenderWindow& window,
                                 const std::string& label,
                                 const std::vector<std::string>& options,
                                 std::vector<sf::FloatRect>& rects,
                                 int selected, float x, float y, float W, float H) {
    unsigned lblSz = static_cast<unsigned>(H * 0.026f);
    sf::Text lbl(UI::toSfStr(label + ":"), m_ctx.font, lblSz);
    lbl.setFillColor(sf::Color(160,160,200));
    lbl.setPosition(x, y);
    window.draw(lbl);

    float btnW  = std::min(W * 0.11f, 95.f);
    float btnH  = H * 0.048f;
    float gap   = W * 0.008f;
    float bx = x, by = y + lblSz + 4.f;
    auto mp = sf::Vector2f(sf::Mouse::getPosition(window));

    for (int i = 0; i < (int)options.size(); ++i) {
        sf::FloatRect r(bx, by, btnW, btnH);
        rects[i] = r;
        bool act = (i == selected), hov = r.contains(mp);
        sf::RectangleShape btn(sf::Vector2f(btnW, btnH));
        btn.setPosition(bx, by);
        btn.setFillColor(act ? sf::Color(40,110,190) : (hov ? sf::Color(50,60,90) : sf::Color(30,30,48)));
        btn.setOutlineThickness(act ? 2.f : 1.f);
        btn.setOutlineColor(act ? sf::Color(80,160,255) : sf::Color(60,60,90));
        window.draw(btn);
        unsigned optSz = (unsigned)std::max(9.f, btnH * 0.40f);
        sf::Text t(UI::toSfStr(options[i]), m_ctx.font, optSz);
        t.setFillColor(act ? sf::Color(255,255,255) : sf::Color(190,190,210));
        sf::FloatRect tb = t.getLocalBounds();
        t.setPosition(bx+(btnW-tb.width)*0.5f-tb.left, by+(btnH-tb.height)*0.5f-tb.top);
        window.draw(t);
        bx += btnW + gap;
    }
}

void EditAdState::handleEvent(sf::Event& event, StateManager& sm) {
    if (event.type == sf::Event::Resized) recalcLayout();
    m_fields[m_focused].handleEvent(event);

    if (event.type == sf::Event::MouseButtonPressed &&
        event.mouseButton.button == sf::Mouse::Left) {
        sf::Vector2f mp((float)event.mouseButton.x, (float)event.mouseButton.y);

        if (m_btnBack.contains(mp))       { sm.pop(); return; }
        if (m_btnSave.contains(mp))       { save(sm); return; }
        if (m_btnPickMain.contains(mp))   { pickMainImage();   return; }
        if (m_btnPickExtra.contains(mp))  { pickExtraImages(); return; }
        if (m_btnClearExtra.contains(mp)) { m_extraImages.clear(); return; }

        for (int i = 0; i < (int)m_btnFuel.size(); ++i)
            if (m_btnFuel[i].contains(mp)) {
                m_selectedFuel = (m_selectedFuel == i) ? -1 : i; return;
            }
        for (int i = 0; i < (int)m_btnBody.size(); ++i)
            if (m_btnBody[i].contains(mp)) {
                m_selectedBody = (m_selectedBody == i) ? -1 : i; return;
            }

        for (int i = 0; i < FIELD_COUNT; ++i)
            if (m_fields[i].bounds.contains(mp)) {
                m_fields[m_focused].focused = false;
                m_focused = i;
                m_fields[m_focused].focused = true;
                break;
            }
    }
    if (event.type == sf::Event::KeyPressed &&
        event.key.code == sf::Keyboard::Tab) {
        m_fields[m_focused].focused = false;
        m_focused = (m_focused + 1) % FIELD_COUNT;
        m_fields[m_focused].focused = true;
    }
}

void EditAdState::render(sf::RenderWindow& window) {
    recalcLayout();
    window.clear(sf::Color(15, 15, 25));
    float W = static_cast<float>(window.getSize().x);
    float H = static_cast<float>(window.getSize().y);

    unsigned titleSz = (unsigned)(H * 0.042f);
    sf::Text title(UI::toSfStr("Edytuj ogloszenie"), m_ctx.font, titleSz);
    title.setFillColor(sf::Color(80,160,255));
    sf::FloatRect tb = title.getLocalBounds();
    title.setPosition(W*0.5f - tb.width*0.5f, H*0.02f);
    window.draw(title);

    for (const auto& f : m_fields) f.draw(window, m_ctx.font);

    float formX   = W * 0.04f;
    float optionY = H * 0.10f + FIELD_COUNT * H * 0.095f + H * 0.01f;
    drawOptionRow(window,"Paliwo",  FUEL_OPTIONS, m_btnFuel,
                  m_selectedFuel, formX, optionY, W, H);
    drawOptionRow(window,"Nadwozie",BODY_OPTIONS, m_btnBody,
                  m_selectedBody, formX, optionY + H*0.11f, W, H);

    float rightX = W * 0.50f;
    auto mp = sf::Vector2f(sf::Mouse::getPosition(window));

    sf::Text imgTitle(UI::toSfStr("Zdjecia:"), m_ctx.font, (unsigned)(H*0.030f));
    imgTitle.setFillColor(sf::Color(140,140,200));
    imgTitle.setPosition(rightX, H*0.06f);
    window.draw(imgTitle);

    UI::drawButton(window, m_ctx.font, m_btnPickMain,
                   m_mainImage.empty() ? "Zdjecie glowne" : "Zmien glowne",
                   m_btnPickMain.contains(mp));

    if (m_previewLoaded) {
        float prevW = W*0.16f, prevH = H*0.18f;
        float prevX = m_btnPickMain.left + m_btnPickMain.width + W*0.01f;
        float prevY = m_btnPickMain.top;
        sf::RectangleShape border(sf::Vector2f(prevW+4, prevH+4));
        border.setPosition(prevX-2, prevY-2);
        border.setFillColor(sf::Color::Transparent);
        border.setOutlineThickness(2); border.setOutlineColor(sf::Color(70,110,190));
        window.draw(border);
        sf::Sprite prev(m_previewTex);
        float sc = std::min(prevW/m_previewTex.getSize().x, prevH/m_previewTex.getSize().y);
        prev.setScale(sc,sc); prev.setPosition(prevX, prevY);
        window.draw(prev);
    }

    UI::drawButton(window, m_ctx.font, m_btnPickExtra,
                   "+ Dodatkowe (" + std::to_string(m_extraImages.size()) + "/10, Ctrl+klik=multi)",
                   m_btnPickExtra.contains(mp));

    if (!m_extraImages.empty()) {
        UI::drawButton(window, m_ctx.font, m_btnClearExtra, "Wyczysc",
                       m_btnClearExtra.contains(mp));
        float thumbSize = W*0.055f;
        float thumbY    = m_btnPickExtra.top + m_btnPickExtra.height + H*0.012f;
        int perRow = (int)((W*0.45f) / (thumbSize + 4.f));
        for (int i = 0; i < (int)m_extraImages.size(); ++i) {
            int col = i % perRow, row = i / perRow;
            float tx = rightX + col*(thumbSize+4.f);
            float ty = thumbY + row*(thumbSize+4.f);
            sf::Texture t;
            sf::RectangleShape box(sf::Vector2f(thumbSize, thumbSize));
            box.setPosition(tx, ty);
            if (t.loadFromFile(m_extraImages[i])) {
                sf::Sprite sp(t);
                float sc2 = std::min(thumbSize/t.getSize().x, thumbSize/t.getSize().y);
                sp.setScale(sc2,sc2); sp.setPosition(tx,ty);
                box.setFillColor(sf::Color::Transparent);
                box.setOutlineThickness(1); box.setOutlineColor(sf::Color(70,100,160));
                window.draw(box); window.draw(sp);
            } else {
                box.setFillColor(sf::Color(45,45,65));
                box.setOutlineThickness(1); box.setOutlineColor(sf::Color(70,70,100));
                window.draw(box);
            }
        }
    }

    UI::drawButton(window, m_ctx.font, m_btnBack, "< Wróc", m_btnBack.contains(mp));
    UI::drawButton(window, m_ctx.font, m_btnSave, "Zapisz zmiany", m_btnSave.contains(mp));

    if (!m_message.empty()) {
        unsigned msgSz = (unsigned)(H*0.028f);
        sf::Text msg(UI::toSfStr(m_message), m_ctx.font, msgSz);
        msg.setFillColor(sf::Color(220,80,80));
        sf::FloatRect mb = msg.getLocalBounds();
        msg.setPosition(W*0.5f - mb.width*0.5f, H*0.82f);
        window.draw(msg);
    }
}
