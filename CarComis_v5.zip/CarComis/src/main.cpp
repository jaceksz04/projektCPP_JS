#include <SFML/Graphics.hpp>
#include <memory>
#include <iostream>
#include <fstream>

#include "CsvCarRepository.h"
#include "CarInventory.h"
#include "CarRenderer.h"
#include "AppContext.h"
#include "IState.h"
#include "MenuState.h"
#include "User.h"

int main() {

    std::ofstream log("log.txt");
    log << "=== CarComis start ===\n"; log.flush();

    // Okno z mozliwoscia zmiany rozmiaru
    sf::RenderWindow window(sf::VideoMode(800, 600), "Komis Samochodowy",
                            sf::Style::Titlebar | sf::Style::Close | sf::Style::Resize);
    window.setFramerateLimit(60);
    log << "Okno OK\n"; log.flush();

    sf::Font font;
    bool fontLoaded = false;
    const char* fontPaths[] = {
        "assets/fonts/DejaVuSans.ttf",
        "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/Arial.ttf",
        "C:/Windows/Fonts/verdana.ttf",
        nullptr
    };
    for (int i = 0; fontPaths[i] != nullptr; ++i) {
        if (font.loadFromFile(fontPaths[i])) {
            log << "Czcionka: " << fontPaths[i] << "\n";
            fontLoaded = true;
            break;
        }
    }
    if (!fontLoaded) {
        log << "BLAD: brak czcionki!\n";
        system("pause");
        return -1;
    }

    system("mkdir data 2>nul");
    auto repo      = std::make_shared<CsvCarRepository>("data/cars.csv");
    auto inventory = std::make_shared<CarInventory>(repo);
    inventory->load();

    if (inventory->getAllCars().empty()) {
        inventory->addCar("Toyota",     "Corolla",  2019,  45000,  72000, "Jeden wlasciciel, stan bardzo dobry.", "");
        inventory->addCar("Volkswagen", "Golf",     2017,  98000,  58000, "Serwisowany w ASO, nowe opony.",       "");
        inventory->addCar("BMW",        "3 Series", 2020,  32000, 125000, "Wersja M-Sport, skorzana tapicerka.",  "");
        inventory->addCar("Ford",       "Focus",    2015, 145000,  34000, "Ekonomiczny, bogate wyposazenie.",     "");
        inventory->addCar("Audi",       "A4",       2018,  77000,  95000, "Quattro, LED, nawigacja.",             "");
        inventory->save();
    }

    CarRenderer renderer(font);
    User currentUser;
    WatchlistManager watchlist("data/watchlist.txt");
    AppContext ctx{ window, font, *inventory, renderer, currentUser, watchlist };

    StateManager stateManager;
    stateManager.push(std::make_shared<MenuState>(ctx));
    log << "Wchodze do petli glownej.\n"; log.flush();

    sf::Clock clock;

    while (window.isOpen() && !stateManager.empty()) {

        float dt = clock.restart().asSeconds();

        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();

            // Obs�uga zmiany rozmiaru okna � aktualizuj widok
            if (event.type == sf::Event::Resized) {
                sf::FloatRect visibleArea(0, 0,
                    static_cast<float>(event.size.width),
                    static_cast<float>(event.size.height));
                window.setView(sf::View(visibleArea));
            }

            if (auto* state = stateManager.current())
                state->handleEvent(event, stateManager);
        }

        if (auto* state = stateManager.current())
            state->update(dt, stateManager);

        stateManager.applyPending();

        if (auto* state = stateManager.current())
            state->render(window);

        window.display();
    }

    inventory->save();
    return 0;
}
