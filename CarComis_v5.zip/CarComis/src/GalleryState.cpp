#include "GalleryState.h"
#include <cmath>
#include <climits>
#include <algorithm>
#include "DetailState.h"
#include "AddAdState.h"
#include "MenuState.h"

const std::vector<std::string> GalleryState::FUEL_OPTIONS = {
    "benzyna","diesel","elektryczny","hybryda"
};
const std::vector<std::string> GalleryState::BODY_OPTIONS = {
    "sedan","kombi","coupe","suv","hatchback"
};

GalleryState::GalleryState(AppContext& ctx) : m_ctx(ctx) {
    m_modalBtnFuel.resize(FUEL_OPTIONS.size());
    m_modalBtnBody.resize(BODY_OPTIONS.size());
    recalcLayout();
    applyFilters();
}

// ── Layout ────────────────────────────────────────────────────────────────────
void GalleryState::recalcLayout() {
    float W = static_cast<float>(m_ctx.window.getSize().x);
    float H = static_cast<float>(m_ctx.window.getSize().y);

    float sideW = std::max(145.f, std::min(210.f, W * 0.19f));
    m_sidebarW  = sideW;

    float pad   = 10.f;
    float fw    = sideW - 2.f * pad;
    float lblSz = std::max(11.f, H * 0.026f);
    float fh    = std::max(24.f, H * 0.050f);
    float btnH  = std::max(26.f, H * 0.060f);
    float gap   = std::max(8.f,  H * 0.012f);
    m_layoutFontH = lblSz;

    float y = pad + lblSz * 1.3f + gap * 2.f;
    m_filterLabelY = y;
    y += lblSz + gap * 3.5f;

    m_filterBrand.bounds    = { pad, y, fw, fh };
    m_filterBrand.label     = "Marka";
    y += fh + gap + lblSz + gap;

    m_filterMinPrice.bounds = { pad, y, fw, fh };
    m_filterMinPrice.label  = "Cena min";
    y += fh + gap + lblSz + gap;

    m_filterMaxPrice.bounds = { pad, y, fw, fh };
    m_filterMaxPrice.label  = "Cena max";
    y += fh + gap * 2.5f;

    m_btnAdvanced = { pad, y, fw, btnH * 0.85f };
    y += btnH * 0.85f + gap;

    m_btnApply  = { pad, y, fw, btnH };
    y += btnH + gap;
    m_btnWatchlist = { pad, y, fw, btnH };
    y += btnH + gap;
    m_btnAddCar = { pad, y, fw, btnH };
    m_btnLogout = { pad, H - btnH - pad, fw, btnH };

    // Przyciski sortowania nad siatka
    float sortH = std::max(22.f, H * 0.048f);
    float sortW = std::max(72.f, (W - sideW) * 0.145f);
    float sx    = sideW + 6.f;
    for (int i = 0; i < 4; ++i)
        m_btnSort[i] = { sx + i * (sortW + 5.f), 4.f, sortW, sortH };

    recalcModal();
}

void GalleryState::recalcModal() {
    float W = static_cast<float>(m_ctx.window.getSize().x);
    float H = static_cast<float>(m_ctx.window.getSize().y);

    // Modal zajmuje 70% szerokosci i 80% wysokosci, min 400x400
    float mw = std::max(400.f, W * 0.70f);
    float mh = std::max(400.f, H * 0.80f);
    float mx = (W - mw) * 0.5f;
    float my = (H - mh) * 0.5f;
    m_modalRect = { mx, my, mw, mh };

    float pad   = mw * 0.04f;   // padding proporcjonalny do szerokosci modalu
    float fw    = mw - 2.f * pad;
    float fh    = std::max(28.f, mh * 0.072f);   // wysokosc pola
    float lblH  = std::max(12.f, mh * 0.040f);   // rozmiar etykiety
    float gap   = std::max(8.f,  mh * 0.018f);   // odstep
    float halfW = (fw - gap) * 0.5f;

    float titleBarH = std::max(36.f, mh * 0.088f);
    float y = my + titleBarH + gap * 1.5f;

    // Rok od / Rok do
    m_advMinYear.bounds = { mx + pad,              y, halfW, fh };
    m_advMinYear.label  = "Rok od";
    m_advMaxYear.bounds = { mx + pad + halfW + gap, y, halfW, fh };
    m_advMaxYear.label  = "Rok do";
    y += fh + lblH + gap * 2.f;

    // Przebieg od / Przebieg do
    m_advMinMileage.bounds = { mx + pad,              y, halfW, fh };
    m_advMinMileage.label  = "Przebieg od";
    m_advMaxMileage.bounds = { mx + pad + halfW + gap, y, halfW, fh };
    m_advMaxMileage.label  = "Przebieg do";
    y += fh + lblH + gap * 2.5f;

    // Paliwo – przyciski wypelniaja szerokosc modalu rowno
    int nf = (int)FUEL_OPTIONS.size();
    float fuelBtnW = (fw - gap * (nf - 1)) / nf;
    float fuelBtnH = std::max(30.f, mh * 0.090f);
    y += lblH + 4.f; // miejsce na etykiete "Paliwo:"
    for (int i = 0; i < nf; ++i)
        m_modalBtnFuel[i] = { mx + pad + i*(fuelBtnW+gap), y, fuelBtnW, fuelBtnH };
    y += fuelBtnH + gap * 2.5f;

    // Nadwozie
    int nb = (int)BODY_OPTIONS.size();
    float bodyBtnW = (fw - gap * (nb - 1)) / nb;
    float bodyBtnH = fuelBtnH;
    y += lblH + 4.f; // miejsce na etykiete "Nadwozie:"
    for (int i = 0; i < nb; ++i)
        m_modalBtnBody[i] = { mx + pad + i*(bodyBtnW+gap), y, bodyBtnW, bodyBtnH };
    y += bodyBtnH + gap * 3.f;

    // Przyciski akcji na dole modalu
    float actionBtnH = std::max(32.f, mh * 0.095f);
    float actionBtnW = fw * 0.38f;
    m_modalBtnClear = { mx + pad,                   y, actionBtnW, actionBtnH };
    m_modalBtnApply = { mx + pad + fw - actionBtnW, y, actionBtnW, actionBtnH };
    m_modalBtnClose = { mx + mw - 30.f, my + 7.f, 24.f, 24.f };
}

// ── Sort ──────────────────────────────────────────────────────────────────────
void GalleryState::toggleSort(SortField f) {
    if (m_sortField == f) {
        m_sortOrder = (m_sortOrder == SortOrder::Asc) ? SortOrder::Desc : SortOrder::Asc;
    } else {
        m_sortField = f;
        m_sortOrder = SortOrder::Asc;
    }
    applyFilters();
}

// ── Filters ───────────────────────────────────────────────────────────────────
void GalleryState::applyFilters() {
    CompositeFilter cf;

    if (!m_filterBrand.value.empty())
        cf.add(std::make_shared<BrandFilter>(m_filterBrand.value));

    double pMin = 0, pMax = 1e9;
    try { if (!m_filterMinPrice.value.empty()) pMin = std::stod(m_filterMinPrice.value); } catch(...) {}
    try { if (!m_filterMaxPrice.value.empty()) pMax = std::stod(m_filterMaxPrice.value); } catch(...) {}
    if (pMin > 0 || pMax < 1e9) cf.add(std::make_shared<PriceFilter>(pMin, pMax));

    // Zaawansowane
    int yMin = 0, yMax = 9999;
    try { if (!m_advMinYear.value.empty()) yMin = std::stoi(m_advMinYear.value); } catch(...) {}
    try { if (!m_advMaxYear.value.empty()) yMax = std::stoi(m_advMaxYear.value); } catch(...) {}
    if (yMin > 0 || yMax < 9999) cf.add(std::make_shared<YearFilter>(yMin, yMax));

    int mMin = 0, mMax = INT_MAX;
    try { if (!m_advMinMileage.value.empty()) mMin = std::stoi(m_advMinMileage.value); } catch(...) {}
    try { if (!m_advMaxMileage.value.empty()) mMax = std::stoi(m_advMaxMileage.value); } catch(...) {}
    if (mMin > 0 || mMax < INT_MAX) cf.add(std::make_shared<MileageFilter>(mMin, mMax));

    if (!m_advFuels.empty()) {
        std::vector<std::string> fuels;
        for (int i : m_advFuels) fuels.push_back(FUEL_OPTIONS[i]);
        cf.add(std::make_shared<FuelFilter>(fuels));
    }
    if (!m_advBodies.empty()) {
        std::vector<std::string> bodies;
        for (int i : m_advBodies) bodies.push_back(BODY_OPTIONS[i]);
        cf.add(std::make_shared<BodyFilter>(bodies));
    }

    m_advFiltersActive = (yMin > 0 || yMax < 9999 || mMin > 0 || mMax < INT_MAX
                          || !m_advFuels.empty() || !m_advBodies.empty());

    m_visible = m_ctx.inventory.filter(cf);

    // Tryb obserwowanych – zachowaj tylko te z watchlisty
    if (m_watchlistMode) {
        m_visible.erase(
            std::remove_if(m_visible.begin(), m_visible.end(),
                [&](const Car& c){ return !m_ctx.watchlist.contains(c.id); }),
            m_visible.end());
    }

    sortCars(m_visible, m_sortField, m_sortOrder);
    m_scrollOffset = 0;
    m_selected = -1;
}

sf::FloatRect GalleryState::cardRect(int i) const {
    float W     = static_cast<float>(m_ctx.window.getSize().x);
    float H     = static_cast<float>(m_ctx.window.getSize().y);
    float gx    = m_sidebarW + 5.f;
    float gridY = m_btnSort[0].top + m_btnSort[0].height + 6.f;
    float cardW = (W - gx - GAP) / COLS - GAP;
    float cardH = (H - gridY - GAP) / 3.f - GAP;
    int col = i % COLS, row = i / COLS - m_scrollOffset;
    return { gx + col*(cardW+GAP) + GAP*0.5f, gridY + row*(cardH+GAP), cardW, cardH };
}

// ── Events ────────────────────────────────────────────────────────────────────
void GalleryState::handleEvent(sf::Event& event, StateManager& sm) {
    if (event.type == sf::Event::Resized) recalcLayout();

    // Modal pochłania wszystkie eventy gdy otwarty
    if (m_modalOpen) {
        // Pola w modalu
        auto passModal = [&](UI::InputField& f, int idx) {
            if (m_advFocused == idx) f.handleEvent(event);
        };
        passModal(m_advMinYear,    0);
        passModal(m_advMaxYear,    1);
        passModal(m_advMinMileage, 2);
        passModal(m_advMaxMileage, 3);

        if (event.type == sf::Event::MouseButtonPressed &&
            event.mouseButton.button == sf::Mouse::Left)
            handleModalClick({ (float)event.mouseButton.x,
                               (float)event.mouseButton.y }, sm);
        return;
    }

    // Sidebar pola
    auto pass = [&](UI::InputField& f, int idx) {
        if (m_focusedField == idx) f.handleEvent(event);
    };
    pass(m_filterBrand, 0); pass(m_filterMinPrice, 1); pass(m_filterMaxPrice, 2);

    if (event.type == sf::Event::MouseButtonPressed &&
        event.mouseButton.button == sf::Mouse::Left) {

        sf::Vector2f mp((float)event.mouseButton.x, (float)event.mouseButton.y);

        auto tryFocus = [&](UI::InputField& f, int idx) -> bool {
            if (!f.bounds.contains(mp)) return false;
            if (m_focusedField == 0) m_filterBrand.focused    = false;
            else if (m_focusedField == 1) m_filterMinPrice.focused = false;
            else if (m_focusedField == 2) m_filterMaxPrice.focused = false;
            f.focused = true; m_focusedField = idx; return true;
        };
        tryFocus(m_filterBrand,0) || tryFocus(m_filterMinPrice,1) || tryFocus(m_filterMaxPrice,2);

        // Sortowanie
        SortField sf4[] = { SortField::Price, SortField::Year,
                            SortField::Mileage, SortField::DateAdded };
        for (int i = 0; i < 4; ++i)
            if (m_btnSort[i].contains(mp)) { toggleSort(sf4[i]); return; }

        if (m_btnApply.contains(mp))    { applyFilters(); return; }
        if (m_btnWatchlist.contains(mp)) {
            m_watchlistMode = !m_watchlistMode;
            applyFilters();
            return;
        }
        if (m_btnAdvanced.contains(mp)) { m_modalOpen = true; recalcModal(); return; }
        if (m_btnLogout.contains(mp))   {
            m_ctx.currentUser = {"", UserRole::Buyer};
            sm.replaceDeferred(std::make_shared<MenuState>(m_ctx)); return;
        }
        if (m_btnAddCar.contains(mp) && m_ctx.currentUser.isSeller()) {
            sm.pushDeferred(std::make_shared<AddAdState>(m_ctx)); return;
        }

        for (int i = 0; i < (int)m_visible.size(); ++i) {
            int row = i / COLS - m_scrollOffset;
            if (row < 0 || row >= 3) continue;
            if (cardRect(i).contains(mp)) {
                sm.pushDeferred(std::make_shared<DetailState>(m_ctx, m_visible[i]));
                break;
            }
        }
    }

    if (event.type == sf::Event::MouseWheelScrolled) {
        m_scrollOffset -= (int)event.mouseWheelScroll.delta;
        int maxOff = std::max(0, (int)std::ceil(m_visible.size() / (float)COLS) - 3);
        m_scrollOffset = std::max(0, std::min(m_scrollOffset, maxOff));
    }
    if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Return)
        applyFilters();
}

void GalleryState::handleModalClick(sf::Vector2f mp, StateManager& sm) {
    // Zamknij
    if (m_modalBtnClose.contains(mp)) { m_modalOpen = false; return; }
    // Klik poza modalem = zamknij
    if (!m_modalRect.contains(mp))    { m_modalOpen = false; return; }

    // Fokus pol
    auto tryFocusAdv = [&](UI::InputField& f, int idx) -> bool {
        if (!f.bounds.contains(mp)) return false;
        if (m_advFocused == 0) m_advMinYear.focused    = false;
        else if (m_advFocused == 1) m_advMaxYear.focused    = false;
        else if (m_advFocused == 2) m_advMinMileage.focused = false;
        else if (m_advFocused == 3) m_advMaxMileage.focused = false;
        f.focused = true; m_advFocused = idx; return true;
    };
    tryFocusAdv(m_advMinYear,0) || tryFocusAdv(m_advMaxYear,1) ||
    tryFocusAdv(m_advMinMileage,2) || tryFocusAdv(m_advMaxMileage,3);

    // Paliwo – toggle multi-select
    for (int i = 0; i < (int)FUEL_OPTIONS.size(); ++i) {
        if (m_modalBtnFuel[i].contains(mp)) {
            auto it = std::find(m_advFuels.begin(), m_advFuels.end(), i);
            if (it != m_advFuels.end()) m_advFuels.erase(it);
            else m_advFuels.push_back(i);
            return;
        }
    }
    // Nadwozie – toggle multi-select
    for (int i = 0; i < (int)BODY_OPTIONS.size(); ++i) {
        if (m_modalBtnBody[i].contains(mp)) {
            auto it = std::find(m_advBodies.begin(), m_advBodies.end(), i);
            if (it != m_advBodies.end()) m_advBodies.erase(it);
            else m_advBodies.push_back(i);
            return;
        }
    }

    if (m_modalBtnClear.contains(mp)) {
        // Wyczysc wszystkie zaawansowane filtry
        m_advMinYear.value    = "";
        m_advMaxYear.value    = "";
        m_advMinMileage.value = "";
        m_advMaxMileage.value = "";
        m_advFuels.clear();
        m_advBodies.clear();
        m_advFocused = -1;
        m_advMinYear.focused = m_advMaxYear.focused =
        m_advMinMileage.focused = m_advMaxMileage.focused = false;
        applyFilters();
        return;
    }
    if (m_modalBtnApply.contains(mp)) {
        applyFilters();
        m_modalOpen = false;
        return;
    }
}

// ── Render ────────────────────────────────────────────────────────────────────
void GalleryState::render(sf::RenderWindow& window) {
    recalcLayout();
    window.clear(sf::Color(15, 15, 25));
    drawSidebar(window);
    drawCarGrid(window);
    if (m_modalOpen) drawModal(window);
}

void GalleryState::drawSidebar(sf::RenderWindow& window) {
    float H   = static_cast<float>(window.getSize().y);
    float pad = 10.f;
    auto mp   = sf::Vector2f(sf::Mouse::getPosition(window));
    bool isSeller = m_ctx.currentUser.isSeller();

    sf::RectangleShape side(sf::Vector2f(m_sidebarW, H));
    side.setFillColor(sf::Color(18, 18, 30));
    side.setOutlineColor(sf::Color(45, 45, 75));
    side.setOutlineThickness(1);
    window.draw(side);

    // Rola
    unsigned roleSz = (unsigned)(m_layoutFontH * 1.1f);
    sf::Text roleLabel(UI::toSfStr(isSeller ? "Sprzedawca" : "Kupujący"), m_ctx.font, roleSz);
    roleLabel.setFillColor(isSeller ? sf::Color(80,210,120) : sf::Color(100,160,230));
    roleLabel.setPosition(pad, pad);
    window.draw(roleLabel);

    // Separator
    sf::RectangleShape sep(sf::Vector2f(m_sidebarW - pad*2.f, 1.f));
    sep.setPosition(pad, m_filterLabelY - 4.f);
    sep.setFillColor(sf::Color(50,50,80));
    window.draw(sep);

    sf::Text fl(UI::toSfStr("Filtry"), m_ctx.font, (unsigned)m_layoutFontH);
    fl.setFillColor(sf::Color(100,100,150));
    fl.setPosition(pad, m_filterLabelY);
    window.draw(fl);

    m_filterBrand.draw(window, m_ctx.font);
    m_filterMinPrice.draw(window, m_ctx.font);
    m_filterMaxPrice.draw(window, m_ctx.font);

    // Przycisk zaawansowane – podswietlony jesli aktywne filtry
    std::string advLbl = m_advFiltersActive ? "Zaawansowane *" : "Zaawansowane...";
    UI::drawButton(window, m_ctx.font, m_btnAdvanced, advLbl,
                   m_btnAdvanced.contains(mp), m_advFiltersActive);

    UI::drawButton(window, m_ctx.font, m_btnApply, "Szukaj", m_btnApply.contains(mp));

    // Przycisk obserwowanych (tylko dla kupujacego)
    if (!isSeller) {
        int watchCount = 0;
        for (const auto& c : m_ctx.inventory.getAllCars())
            if (m_ctx.watchlist.contains(c.id)) ++watchCount;
        std::string wlbl = m_watchlistMode
            ? "* Obserwowane (" + std::to_string(watchCount) + ")"
            : "Obserwowane (" + std::to_string(watchCount) + ")";
        // Zolty gdy aktywny tryb
        sf::FloatRect r = m_btnWatchlist;
        sf::RectangleShape wbg(sf::Vector2f(r.width, r.height));
        wbg.setPosition(r.left, r.top);
        wbg.setFillColor(m_watchlistMode
            ? sf::Color(140, 100, 10)
            : (r.contains(mp) ? sf::Color(50,60,90) : sf::Color(40,45,65)));
        wbg.setOutlineThickness(m_watchlistMode ? 2.f : 1.f);
        wbg.setOutlineColor(m_watchlistMode ? sf::Color(230,180,40) : sf::Color(80,80,110));
        window.draw(wbg);
        unsigned wsz = static_cast<unsigned>(std::max(10.f, r.height * 0.42f));
        sf::Text wt(UI::toSfStr(wlbl), m_ctx.font, wsz);
        wt.setFillColor(m_watchlistMode ? sf::Color(255,220,80) : sf::Color(220,220,240));
        sf::FloatRect wb = wt.getLocalBounds();
        wt.setPosition(r.left + (r.width  - wb.width )*0.5f - wb.left,
                       r.top  + (r.height - wb.height)*0.5f - wb.top);
        window.draw(wt);
    }

    if (isSeller)
        UI::drawButton(window, m_ctx.font, m_btnAddCar, "+ Nowa oferta",
                       m_btnAddCar.contains(mp));

    UI::drawButton(window, m_ctx.font, m_btnLogout,
                   isSeller ? "Wyloguj" : "< Menu", m_btnLogout.contains(mp));

    // Pasek sortowania
    float W = static_cast<float>(window.getSize().x);
    const char* sortNames[] = { "Cena","Rok","Przebieg","Najnowsze" };
    SortField   sortFields[]= { SortField::Price, SortField::Year,
                                SortField::Mileage, SortField::DateAdded };
    for (int i = 0; i < 4; ++i) {
        bool active = (m_sortField == sortFields[i]);
        std::string lbl = sortNames[i];
        if (active) lbl += (m_sortOrder == SortOrder::Asc ? " ^" : " v");
        UI::drawButton(window, m_ctx.font, m_btnSort[i], lbl,
                       m_btnSort[i].contains(mp), active);
    }

    // Licznik
    unsigned cntSz = (unsigned)std::max(10.f, m_layoutFontH);
    float cntX = m_btnSort[3].left + m_btnSort[3].width + 12.f;
    sf::Text cnt(UI::toSfStr("Wyniki: " + std::to_string(m_visible.size())),
                 m_ctx.font, cntSz);
    cnt.setFillColor(sf::Color(130,130,155));
    cnt.setPosition(cntX, m_btnSort[0].top + (m_btnSort[0].height - cntSz)*0.5f);
    window.draw(cnt);
}

void GalleryState::drawCarGrid(sf::RenderWindow& window) {
    float H = static_cast<float>(window.getSize().y);
    for (int i = 0; i < (int)m_visible.size(); ++i) {
        int row = i/COLS - m_scrollOffset;
        if (row < 0 || row >= 3) continue;
        sf::FloatRect r = cardRect(i);
        m_ctx.renderer.drawCard(window, m_visible[i], r, i==m_selected);

        // Gwiazdka obserwowanego (gorny prawy rog karty)
        if (!m_ctx.currentUser.isSeller() &&
            m_ctx.watchlist.contains(m_visible[i].id)) {
            unsigned starSz = static_cast<unsigned>(std::max(12.f, r.height * 0.10f));
            sf::Text star(UI::toSfStr("*"), m_ctx.font, starSz);
            star.setFillColor(sf::Color(230, 180, 40));
            star.setPosition(r.left + r.width - starSz - 4.f, r.top + 4.f);
            window.draw(star);
        }
    }
    if (m_visible.empty()) {
        unsigned sz = (unsigned)std::max(12.f, H*0.030f);
        sf::Text t(UI::toSfStr("Brak ofert spelniajacych kryteria."), m_ctx.font, sz);
        t.setFillColor(sf::Color(130,130,155));
        t.setPosition(m_sidebarW+30.f, H*0.4f);
        window.draw(t);
    }
}

// ── Modal ─────────────────────────────────────────────────────────────────────
void GalleryState::drawModal(sf::RenderWindow& window) {
    float W = static_cast<float>(window.getSize().x);
    float H = static_cast<float>(window.getSize().y);
    auto mp = sf::Vector2f(sf::Mouse::getPosition(window));

    // Przyciemnienie tla
    sf::RectangleShape overlay(sf::Vector2f(W, H));
    overlay.setFillColor(sf::Color(0, 0, 0, 160));
    window.draw(overlay);

    // Okno modalu
    sf::RectangleShape bg(sf::Vector2f(m_modalRect.width, m_modalRect.height));
    bg.setPosition(m_modalRect.left, m_modalRect.top);
    bg.setFillColor(sf::Color(22, 22, 38));
    bg.setOutlineThickness(2.f);
    bg.setOutlineColor(sf::Color(60, 80, 140));
    window.draw(bg);

    // Pasek tytulu
    float titleBarH = std::max(32.f, H * 0.062f);
    sf::RectangleShape titleBar(sf::Vector2f(m_modalRect.width, titleBarH));
    titleBar.setPosition(m_modalRect.left, m_modalRect.top);
    titleBar.setFillColor(sf::Color(28, 35, 60));
    window.draw(titleBar);

    unsigned titleSz = (unsigned)std::max(13.f, H * 0.034f);
    sf::Text titleTxt(UI::toSfStr("Zaawansowane filtry"), m_ctx.font, titleSz);
    titleTxt.setFillColor(sf::Color(160, 185, 255));
    titleTxt.setPosition(m_modalRect.left + 14.f,
                         m_modalRect.top + (titleBarH - titleSz) * 0.5f);
    window.draw(titleTxt);

    // Przycisk X
    sf::RectangleShape closeBg(sf::Vector2f(m_modalBtnClose.width, m_modalBtnClose.height));
    closeBg.setPosition(m_modalBtnClose.left, m_modalBtnClose.top);
    closeBg.setFillColor(m_modalBtnClose.contains(mp)
        ? sf::Color(180, 50, 50) : sf::Color(90, 40, 40));
    window.draw(closeBg);
    sf::Text closeX(UI::toSfStr("X"), m_ctx.font, (unsigned)std::max(10.f, H*0.026f));
    closeX.setFillColor(sf::Color(230, 200, 200));
    sf::FloatRect cb = closeX.getLocalBounds();
    closeX.setPosition(m_modalBtnClose.left + (m_modalBtnClose.width  - cb.width)*0.5f - cb.left,
                       m_modalBtnClose.top  + (m_modalBtnClose.height - cb.height)*0.5f - cb.top);
    window.draw(closeX);

    // Pola tekstowe
    m_advMinYear.draw(window, m_ctx.font);
    m_advMaxYear.draw(window, m_ctx.font);
    m_advMinMileage.draw(window, m_ctx.font);
    m_advMaxMileage.draw(window, m_ctx.font);

    unsigned secSz = (unsigned)std::max(11.f, H * 0.026f);
    float pad = 16.f;

    // Oblicz pozycje etykiet (nad przyciskami opcji)
    auto drawSection = [&](const std::string& lbl,
                           const std::vector<std::string>& opts,
                           std::vector<sf::FloatRect>& rects,
                           const std::vector<int>& selected) {
        if (rects.empty()) return;
        float labelY = rects[0].top - secSz - 6.f;
        sf::Text s(UI::toSfStr(lbl), m_ctx.font, secSz);
        s.setFillColor(sf::Color(130, 150, 210));
        s.setPosition(m_modalRect.left + pad, labelY);
        window.draw(s);
        for (int i = 0; i < (int)opts.size(); ++i) {
            bool act = std::find(selected.begin(), selected.end(), i) != selected.end();
            bool hov = rects[i].contains(mp);
            sf::RectangleShape btn(sf::Vector2f(rects[i].width, rects[i].height));
            btn.setPosition(rects[i].left, rects[i].top);
            btn.setFillColor(act ? sf::Color(40,110,190)
                           : (hov ? sf::Color(50,60,90) : sf::Color(30,30,48)));
            btn.setOutlineThickness(act ? 2.f : 1.f);
            btn.setOutlineColor(act ? sf::Color(80,160,255) : sf::Color(60,60,90));
            window.draw(btn);
            unsigned optSz = (unsigned)std::max(9.f, rects[i].height * 0.38f);
            sf::Text t(UI::toSfStr(opts[i]), m_ctx.font, optSz);
            t.setFillColor(act ? sf::Color(255,255,255) : sf::Color(190,190,210));
            sf::FloatRect tb = t.getLocalBounds();
            t.setPosition(rects[i].left + (rects[i].width  - tb.width )*0.5f - tb.left,
                          rects[i].top  + (rects[i].height - tb.height)*0.5f - tb.top);
            window.draw(t);
        }
    };

    drawSection("Paliwo:",    FUEL_OPTIONS, m_modalBtnFuel, m_advFuels);
    drawSection("Nadwozie:",  BODY_OPTIONS, m_modalBtnBody, m_advBodies);

    // Przyciski Wyczysc / Zastosuj
    UI::drawButton(window, m_ctx.font, m_modalBtnClear,
                   "Wyczysc filtry", m_modalBtnClear.contains(mp));
    UI::drawButton(window, m_ctx.font, m_modalBtnApply,
                   "Zastosuj", m_modalBtnApply.contains(mp), true);
}
