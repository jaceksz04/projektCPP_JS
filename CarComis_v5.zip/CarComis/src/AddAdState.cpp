#include "AddAdState.h"
#include "GalleryState.h"
#include <stdexcept>
#include <algorithm>

const std::vector<std::string> AddAdState::FUEL_OPTIONS = {
    "benzyna", "diesel", "elektryczny", "hybryda"
};
const std::vector<std::string> AddAdState::BODY_OPTIONS = {
    "sedan", "kombi", "coupe", "suv", "hatchback"
};

AddAdState::AddAdState(AppContext& ctx) : m_ctx(ctx) {
    std::array<std::string, FIELD_COUNT> labels = {
        "Marka", "Model", "Rok produkcji", "Przebieg (km)", "Cena (PLN)", "Opis"
    };
    for (int i = 0; i < FIELD_COUNT; ++i) {
        m_fields[i].label   = labels[i];
        m_fields[i].focused = (i == 0);
    }
    recalcLayout();
}

void AddAdState::recalcLayout() {
    float W = static_cast<float>(m_ctx.window.getSize().x);
    float H = static_cast<float>(m_ctx.window.getSize().y);

    float formX  = W * 0.04f;
    float startY = H * 0.10f;
    float stepY  = H * 0.095f;
    float fieldW = W * 0.38f;
    float fieldH = H * 0.048f;

    for (int i = 0; i < FIELD_COUNT; ++i)
        m_fields[i].bounds = { formX, startY + i * stepY, fieldW, fieldH };

    float rightX  = W * 0.50f;
    float imgBtnW = W * 0.20f;
    float btnH    = H * 0.055f;

    m_btnPickMain   = { rightX,                        H * 0.10f, imgBtnW,     btnH };
    m_btnPickExtra  = { rightX,                        H * 0.19f, imgBtnW,     btnH };
    m_btnClearExtra = { rightX + imgBtnW + W * 0.01f,  H * 0.19f, W * 0.09f,  btnH };

    m_btnSave = { W * 0.36f, H * 0.88f, W * 0.14f, btnH };
    m_btnBack = { W * 0.02f, H * 0.02f, W * 0.10f, H * 0.05f };

    // Przyciski paliwa i nadwozia obliczane dynamicznie w drawOptionRow
    m_btnFuel.assign(FUEL_OPTIONS.size(), sf::FloatRect{});
    m_btnBody.assign(BODY_OPTIONS.size(), sf::FloatRect{});
}

void AddAdState::pickMainImage() {
    std::string path = UI::openFileDialog("Wybierz zdjecie glowne");
    if (!path.empty()) {
        m_mainImage = path;
        m_previewLoaded = m_previewTex.loadFromFile(path);
    }
}

void AddAdState::pickExtraImage() {
    auto paths = UI::openFileDialogMulti("Wybierz dodatkowe zdjecia (max 10)");
    for (const auto& p : paths) {
        if (m_extraImages.size() >= 10) break;
        m_extraImages.push_back(p);
    }
}

void AddAdState::save(StateManager& sm) {
    try {
        std::string brand  = m_fields[0].value;
        std::string model  = m_fields[1].value;
        int    year        = std::stoi(m_fields[2].value);
        int    mileage     = std::stoi(m_fields[3].value);
        double price       = std::stod(m_fields[4].value);
        std::string desc   = m_fields[5].value;

        if (brand.empty() || model.empty())
            throw std::invalid_argument("Marka i model sa wymagane.");

        std::string fuel = (m_selectedFuel >= 0) ? FUEL_OPTIONS[m_selectedFuel] : "";
        std::string body = (m_selectedBody >= 0) ? BODY_OPTIONS[m_selectedBody] : "";

        m_ctx.inventory.addCar(brand, model, year, mileage, price,
                               desc, m_mainImage, m_extraImages, fuel, body);
        m_ctx.inventory.save();
        sm.replaceDeferred(std::make_shared<GalleryState>(m_ctx));
    } catch (const std::exception& e) {
        m_message = std::string("Blad: ") + e.what();
    }
}

void AddAdState::drawOptionRow(sf::RenderWindow& window,
                                const std::string& label,
                                const std::vector<std::string>& options,
                                std::vector<sf::FloatRect>& rects,
                                int selected,
                                float x, float y, float W, float H) {
    unsigned lblSz = static_cast<unsigned>(H * 0.026f);
    sf::Text lbl(UI::toSfStr(label + ":"), m_ctx.font, lblSz);
    lbl.setFillColor(sf::Color(160, 160, 200));
    lbl.setPosition(x, y);
    window.draw(lbl);

    float btnW  = std::min(W * 0.11f, 95.f);
    float btnH  = H * 0.048f;
    float gap   = W * 0.008f;
    float bx    = x;
    float by    = y + lblSz + 4.f;
    auto mp     = sf::Vector2f(sf::Mouse::getPosition(window));

    for (int i = 0; i < (int)options.size(); ++i) {
        sf::FloatRect r(bx, by, btnW, btnH);
        rects[i] = r;

        bool isActive  = (i == selected);
        bool isHovered = r.contains(mp);

        sf::RectangleShape btn(sf::Vector2f(btnW, btnH));
        btn.setPosition(bx, by);
        if (isActive)       btn.setFillColor(sf::Color(40, 110, 190));
        else if (isHovered) btn.setFillColor(sf::Color(50, 60, 90));
        else                btn.setFillColor(sf::Color(30, 30, 48));
        btn.setOutlineThickness(isActive ? 2.f : 1.f);
        btn.setOutlineColor(isActive ? sf::Color(80, 160, 255) : sf::Color(60, 60, 90));
        window.draw(btn);

        unsigned optSz = static_cast<unsigned>(std::max(9.f, btnH * 0.40f));
        sf::Text t(UI::toSfStr(options[i]), m_ctx.font, optSz);
        t.setFillColor(isActive ? sf::Color(255, 255, 255) : sf::Color(190, 190, 210));
        sf::FloatRect tb = t.getLocalBounds();
        t.setPosition(bx + (btnW - tb.width) * 0.5f - tb.left,
                      by  + (btnH - tb.height) * 0.5f - tb.top);
        window.draw(t);

        bx += btnW + gap;
    }
}

void AddAdState::handleEvent(sf::Event& event, StateManager& sm) {
    if (event.type == sf::Event::Resized) recalcLayout();

    m_fields[m_focused].handleEvent(event);

    if (event.type == sf::Event::MouseButtonPressed &&
        event.mouseButton.button == sf::Mouse::Left) {

        sf::Vector2f mp(static_cast<float>(event.mouseButton.x),
                        static_cast<float>(event.mouseButton.y));

        if (m_btnBack.contains(mp))         { sm.pop(); return; }
        if (m_btnSave.contains(mp))         { save(sm); return; }
        if (m_btnPickMain.contains(mp))     { pickMainImage();  return; }
        if (m_btnPickExtra.contains(mp))    { pickExtraImage(); return; }
        if (m_btnClearExtra.contains(mp))   { m_extraImages.clear(); return; }

        for (int i = 0; i < (int)m_btnFuel.size(); ++i)
            if (m_btnFuel[i].contains(mp)) {
                m_selectedFuel = (m_selectedFuel == i) ? -1 : i;
                return;
            }
        for (int i = 0; i < (int)m_btnBody.size(); ++i)
            if (m_btnBody[i].contains(mp)) {
                m_selectedBody = (m_selectedBody == i) ? -1 : i;
                return;
            }

        for (int i = 0; i < FIELD_COUNT; ++i)
            if (m_fields[i].bounds.contains(mp)) {
                m_fields[m_focused].focused = false;
                m_focused = i;
                m_fields[m_focused].focused = true;
                break;
            }
    }

    if (event.type == sf::Event::KeyPressed &&
        event.key.code == sf::Keyboard::Tab) {
        m_fields[m_focused].focused = false;
        m_focused = (m_focused + 1) % FIELD_COUNT;
        m_fields[m_focused].focused = true;
    }
}

void AddAdState::render(sf::RenderWindow& window) {
    recalcLayout();
    window.clear(sf::Color(15, 15, 25));

    float W = static_cast<float>(window.getSize().x);
    float H = static_cast<float>(window.getSize().y);

    // Tytul
    unsigned titleSz = static_cast<unsigned>(H * 0.042f);
    sf::Text title(UI::toSfStr("Dodaj nowe ogloszenie"), m_ctx.font, titleSz);
    title.setFillColor(sf::Color(80, 160, 255));
    sf::FloatRect tb = title.getLocalBounds();
    title.setPosition(W * 0.5f - tb.width * 0.5f, H * 0.02f);
    window.draw(title);

    // Pola formularza
    for (const auto& f : m_fields) f.draw(window, m_ctx.font);

    // Paliwo i nadwozie (pod polami formularza, lewa strona)
    float formX   = W * 0.04f;
    float optionY = H * 0.10f + FIELD_COUNT * H * 0.095f + H * 0.01f;
    drawOptionRow(window, "Paliwo", FUEL_OPTIONS, m_btnFuel,
                  m_selectedFuel, formX, optionY, W, H);
    drawOptionRow(window, "Nadwozie", BODY_OPTIONS, m_btnBody,
                  m_selectedBody, formX, optionY + H * 0.11f, W, H);

    // Sekcja zdjec (prawa strona)
    float rightX = W * 0.50f;
    auto mp = sf::Vector2f(sf::Mouse::getPosition(window));

    unsigned secSz = static_cast<unsigned>(H * 0.030f);
    sf::Text imgTitle(UI::toSfStr("Zdjecia:"), m_ctx.font, secSz);
    imgTitle.setFillColor(sf::Color(140, 140, 200));
    imgTitle.setPosition(rightX, H * 0.06f);
    window.draw(imgTitle);

    UI::drawButton(window, m_ctx.font, m_btnPickMain,
                   m_mainImage.empty() ? "Zdjecie glowne" : "Zmien glowne",
                   m_btnPickMain.contains(mp));

    if (m_previewLoaded) {
        float prevW = W * 0.16f, prevH = H * 0.18f;
        float prevX = m_btnPickMain.left + m_btnPickMain.width + W * 0.01f;
        float prevY = m_btnPickMain.top;
        sf::RectangleShape border(sf::Vector2f(prevW + 4, prevH + 4));
        border.setPosition(prevX - 2, prevY - 2);
        border.setFillColor(sf::Color::Transparent);
        border.setOutlineThickness(2);
        border.setOutlineColor(sf::Color(70, 110, 190));
        window.draw(border);
        sf::Sprite preview(m_previewTex);
        float sc = std::min(prevW / m_previewTex.getSize().x,
                            prevH / m_previewTex.getSize().y);
        preview.setScale(sc, sc);
        preview.setPosition(prevX, prevY);
        window.draw(preview);
    }

    UI::drawButton(window, m_ctx.font, m_btnPickExtra,
                   "+ Dodatkowe (" + std::to_string(m_extraImages.size()) + "/10)",
                   m_btnPickExtra.contains(mp));

    if (!m_extraImages.empty()) {
        UI::drawButton(window, m_ctx.font, m_btnClearExtra, "Wyczysc",
                       m_btnClearExtra.contains(mp));
        float thumbSize = W * 0.055f;
        float gap       = W * 0.006f;
        float startY    = m_btnPickExtra.top + m_btnPickExtra.height + H * 0.012f;
        int   perRow    = (int)((W * 0.46f) / (thumbSize + gap));
        if (perRow < 1) perRow = 1;
        for (int i = 0; i < (int)m_extraImages.size(); ++i) {
            int   col    = i % perRow;
            int   row    = i / perRow;
            float thumbX = rightX + col * (thumbSize + gap);
            float thumbY = startY + row * (thumbSize + gap);
            sf::Texture t;
            sf::RectangleShape box(sf::Vector2f(thumbSize, thumbSize));
            box.setPosition(thumbX, thumbY);
            if (t.loadFromFile(m_extraImages[i])) {
                sf::Sprite sp(t);
                float sc2 = std::min(thumbSize / t.getSize().x,
                                     thumbSize / t.getSize().y);
                sp.setScale(sc2, sc2);
                sp.setPosition(thumbX, thumbY);
                box.setFillColor(sf::Color::Transparent);
                box.setOutlineThickness(1);
                box.setOutlineColor(sf::Color(70, 100, 160));
                window.draw(box);
                window.draw(sp);
            } else {
                box.setFillColor(sf::Color(45, 45, 65));
                box.setOutlineThickness(1);
                box.setOutlineColor(sf::Color(70, 70, 100));
                window.draw(box);
            }
        }
    }

    // Przyciski akcji
    UI::drawButton(window, m_ctx.font, m_btnBack, "< Wróc",   m_btnBack.contains(mp));
    UI::drawButton(window, m_ctx.font, m_btnSave, "Zapisz",   m_btnSave.contains(mp));

    // Podpowiedz
    unsigned hintSz = static_cast<unsigned>(H * 0.022f);
    sf::Text hint(UI::toSfStr("Tab = nastepne pole"), m_ctx.font, hintSz);
    hint.setFillColor(sf::Color(70, 70, 100));
    hint.setPosition(W * 0.04f, H * 0.94f);
    window.draw(hint);

    if (!m_message.empty()) {
        unsigned msgSz = static_cast<unsigned>(H * 0.028f);
        sf::Text msg(UI::toSfStr(m_message), m_ctx.font, msgSz);
        msg.setFillColor(sf::Color(220, 80, 80));
        sf::FloatRect mb = msg.getLocalBounds();
        msg.setPosition(W * 0.5f - mb.width * 0.5f, H * 0.82f);
        window.draw(msg);
    }
}
