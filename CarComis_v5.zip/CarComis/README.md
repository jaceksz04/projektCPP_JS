# CarComis – Komis Samochodowy w C++/SFML

## Struktura plików

```
CarComis/
├── CarComis.cbp              ← projekt Code::Blocks
├── assets/
│   ├── fonts/
│   │   └── DejaVuSans.ttf   ← czcionka (pobierz z dejavu-fonts.org)
│   └── images/              ← zdjęcia aut (opcjonalne .jpg/.png)
├── data/
│   └── cars.csv             ← baza danych (tworzony automatycznie)
├── include/
│   ├── Car.h                ← encja danych pojazdu
│   ├── ICarRepository.h     ← interfejs repozytorium (ISP + DIP)
│   ├── CsvCarRepository.h   ← implementacja CSV (OCP)
│   ├── FilterStrategy.h     ← strategie filtrowania (OCP + Strategy)
│   ├── CarInventory.h       ← logika biznesowa (SRP + DIP)
│   ├── CarRenderer.h        ← renderowanie (SRP)
│   ├── User.h               ← rola użytkownika
│   ├── AppContext.h         ← kontekst wstrzyknięcia (DIP)
│   ├── IState.h             ← interfejs stanu + StateManager (LSP)
│   ├── UIHelper.h           ← narzędzia GUI wielokrotnego użytku
│   ├── MenuState.h          ← ekran menu
│   ├── GalleryState.h       ← galeria z filtrami
│   ├── DetailState.h        ← widok szczegółowy
│   └── AddAdState.h         ← formularz dodawania
└── src/
    ├── main.cpp             ← główna pętla SFML
    ├── CsvCarRepository.cpp
    ├── CarInventory.cpp
    ├── CarRenderer.cpp
    ├── MenuState.cpp
    ├── GalleryState.cpp
    ├── DetailState.cpp
    └── AddAdState.cpp
```

---

## Realizacja zasad SOLID

### S – Single Responsibility Principle
| Klasa/plik | Jedna odpowiedzialność |
|---|---|
| `Car` | Przechowywanie danych pojazdu |
| `CarInventory` | Logika biznesowa komisu (CRUD, filtrowanie) |
| `CarRenderer` | Rysowanie danych pojazdu w SFML |
| `CsvCarRepository` | Serializacja/deserializacja do pliku CSV |
| Każdy `*State` | Obsługa jednego ekranu aplikacji |

> `CarInventory` i `CarRenderer` są celowo rozdzielone –  
> zmiana sposobu renderowania (np. na OpenGL) nie dotyka logiki biznesowej.

---

### O – Open/Closed Principle
Filtrowanie oparte jest na interfejsie `IFilterStrategy`:
```cpp
struct IFilterStrategy { virtual bool matches(const Car&) const = 0; };
struct PriceFilter  : IFilterStrategy { ... };  // gotowe
struct BrandFilter  : IFilterStrategy { ... };  // gotowe
struct YearFilter   : IFilterStrategy { ... };  // gotowe
// Nowe kryterium? → nowa klasa, zero zmian w CarInventory::filter()
```
`CompositeFilter` łączy wiele kryteriów (AND) bez zmiany istniejącego kodu.  
Analogicznie: nowy nośnik danych = nowa klasa `ICarRepository` (np. `SqliteRepository`).

---

### L – Liskov Substitution Principle
`CsvCarRepository` implementuje **wszystkie** metody `ICarRepository`.  
Każdy `*State` implementuje **wszystkie** metody `IState` (handleEvent/update/render).  
`StateManager` operuje wyłącznie na `IState*` – podmiana stanu jest niewidoczna dla pętli głównej.

---

### I – Interface Segregation Principle
`ICarRepository` definiuje **minimalny** kontrakt (add/remove/getAll/load/save/nextId).  
`IState` definiuje **minimalny** kontrakt dla stanów GUI (handleEvent/update/render).  
GUI nie importuje nic z warstwy danych – zależność idzie przez `AppContext`.

---

### D – Dependency Inversion Principle
```
main()
  └─ tworzy CsvCarRepository (konkret)
  └─ wstrzykuje przez ICarRepository do CarInventory (abstrakcja)
  └─ tworzy AppContext { inventory, renderer, ... }
       └─ przekazywany do stanów przez referencję
            └─ GalleryState zna tylko CarInventory & CarRenderer
               (nie wie nic o CSV, plikach, sieciach)
```
Stany GUI **nie tworzą** zależności – dostają je z zewnątrz (Dependency Injection).

---

## Wzorce projektowe

| Wzorzec | Gdzie |
|---|---|
| **State** | `IState`, `StateManager`, `MenuState/GalleryState/DetailState/AddAdState` |
| **Strategy** | `IFilterStrategy`, `PriceFilter`, `BrandFilter`, `YearFilter`, `CompositeFilter` |
| **Repository** | `ICarRepository`, `CsvCarRepository` |
| **Composite** | `CompositeFilter` łączy strategie |
| **Dependency Injection** | `AppContext` przekazywany do wszystkich State'ów |

---

## Konfiguracja Code::Blocks (Windows + SFML)

1. Pobierz SFML 2.6 dla MinGW ze strony sfml-dev.org
2. W `Project → Build Options → Compiler`:  
   - Dodaj katalog `include/` projektu  
   - Dodaj katalog `SFML/include`
3. W `Linker`:  
   - Dodaj katalog `SFML/lib`  
   - Dodaj biblioteki: `sfml-graphics`, `sfml-window`, `sfml-system`
4. Skopiuj DLL-e SFML do katalogu z exe (bin/Debug lub bin/Release)
5. Umieść czcionkę `DejaVuSans.ttf` w `assets/fonts/`
6. Skompiluj i uruchom!

---

## Przepływ aplikacji

```
main()
  │
  ├─ MenuState       → wybór roli (Kupujący / Sprzedawca)
  │
  └─ GalleryState    → lista aut, filtry, sortowanie
       │
       ├─ [push] DetailState   → widok szczegółowy + zakup/usuń
       │
       └─ [push] AddAdState    → formularz dodawania (tylko Sprzedawca)
```
