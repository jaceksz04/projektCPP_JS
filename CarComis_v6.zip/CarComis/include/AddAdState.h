#pragma once
#include "IState.h"
#include "AppContext.h"
#include "UIHelper.h"
#include <array>
#include <string>
#include <vector>

class AddAdState : public IState {
public:
    explicit AddAdState(AppContext& ctx);

    void handleEvent(sf::Event& event, StateManager& sm) override;
    void update(float dt, StateManager& sm) override {}
    void render(sf::RenderWindow& window) override;

private:
    AppContext& m_ctx;

    static constexpr int FIELD_COUNT = 6;
    std::array<UI::InputField, FIELD_COUNT> m_fields;
    int m_focused = 0;

    // Zdjecia
    std::string              m_mainImage;
    std::vector<std::string> m_extraImages;
    sf::Texture m_previewTex;
    bool        m_previewLoaded = false;

    // Wybor paliwa i nadwozia (indeks aktywnej opcji, -1 = brak)
    static const std::vector<std::string> FUEL_OPTIONS;
    static const std::vector<std::string> BODY_OPTIONS;
    static const std::vector<std::string> GEARBOX_OPTIONS;
    int m_selectedFuel    = -1;
    int m_selectedBody    = -1;
    int m_selectedGearbox = -1;
    UI::InputField m_powerField;  // moc silnika w KM

    // Przyciski
    sf::FloatRect m_btnSave;
    sf::FloatRect m_btnBack;
    sf::FloatRect m_btnPickMain;
    sf::FloatRect m_btnPickExtra;
    sf::FloatRect m_btnClearExtra;

    // Przyciski opcji paliwa i nadwozia
    std::vector<sf::FloatRect> m_btnFuel;
    std::vector<sf::FloatRect> m_btnBody;
    std::vector<sf::FloatRect> m_btnGearbox;

    std::string m_message;

    void recalcLayout();
    void save(StateManager& sm);
    void pickMainImage();
    void pickExtraImage();
    void drawOptionRow(sf::RenderWindow& window,
                       const std::string& label,
                       const std::vector<std::string>& options,
                       std::vector<sf::FloatRect>& rects,
                       int selected, float x, float y, float W, float H);
};
