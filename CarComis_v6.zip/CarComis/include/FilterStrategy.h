#pragma once
#include "Car.h"
#include <vector>
#include <algorithm>
#include <string>

// ── Filtry (OCP) ──────────────────────────────────────────────────────────────
struct IFilterStrategy {
    virtual ~IFilterStrategy() = default;
    virtual bool matches(const Car& car) const = 0;
};

struct PriceFilter : IFilterStrategy {
    double minPrice, maxPrice;
    PriceFilter(double mn, double mx) : minPrice(mn), maxPrice(mx) {}
    bool matches(const Car& car) const override {
        return car.price >= minPrice && car.price <= maxPrice;
    }
};

struct BrandFilter : IFilterStrategy {
    std::string query;
    explicit BrandFilter(const std::string& q) : query(q) {}
    bool matches(const Car& car) const override {
        std::string b = car.brand, q = query;
        std::transform(b.begin(), b.end(), b.begin(), ::tolower);
        std::transform(q.begin(), q.end(), q.begin(), ::tolower);
        return b.find(q) != std::string::npos;
    }
};

struct ModelFilter : IFilterStrategy {
    std::string query;
    explicit ModelFilter(const std::string& q) : query(q) {}
    bool matches(const Car& car) const override {
        std::string m = car.model, q = query;
        std::transform(m.begin(), m.end(), m.begin(), ::tolower);
        std::transform(q.begin(), q.end(), q.begin(), ::tolower);
        return m.find(q) != std::string::npos;
    }
};

struct YearFilter : IFilterStrategy {
    int minYear, maxYear;
    YearFilter(int mn, int mx) : minYear(mn), maxYear(mx) {}
    bool matches(const Car& car) const override {
        return car.year >= minYear && car.year <= maxYear;
    }
};

struct MileageFilter : IFilterStrategy {
    int minMileage, maxMileage;
    MileageFilter(int mn, int mx) : minMileage(mn), maxMileage(mx) {}
    bool matches(const Car& car) const override {
        return car.mileage >= minMileage && car.mileage <= maxMileage;
    }
};

struct FuelFilter : IFilterStrategy {
    std::vector<std::string> fuels;
    explicit FuelFilter(const std::vector<std::string>& f) : fuels(f) {}
    bool matches(const Car& car) const override {
        if (fuels.empty()) return true;
        std::string d = car.fuelType;
        std::transform(d.begin(), d.end(), d.begin(), ::tolower);
        for (auto f : fuels) {
            std::transform(f.begin(), f.end(), f.begin(), ::tolower);
            if (d == f) return true;
        }
        return false;
    }
};

struct BodyFilter : IFilterStrategy {
    std::vector<std::string> bodies;
    explicit BodyFilter(const std::vector<std::string>& b) : bodies(b) {}
    bool matches(const Car& car) const override {
        if (bodies.empty()) return true;
        std::string d = car.bodyType;
        std::transform(d.begin(), d.end(), d.begin(), ::tolower);
        for (auto b : bodies) {
            std::transform(b.begin(), b.end(), b.begin(), ::tolower);
            if (d == b) return true;
        }
        return false;
    }
};

struct EnginePowerFilter : IFilterStrategy {
    int minPower, maxPower;
    EnginePowerFilter(int mn, int mx) : minPower(mn), maxPower(mx) {}
    bool matches(const Car& car) const override {
        if (car.enginePower <= 0) return true;
        return car.enginePower >= minPower && car.enginePower <= maxPower;
    }
};

struct GearboxFilter : IFilterStrategy {
    std::vector<std::string> gearboxes;
    explicit GearboxFilter(const std::vector<std::string>& g) : gearboxes(g) {}
    bool matches(const Car& car) const override {
        if (gearboxes.empty()) return true;
        std::string d = car.gearbox;
        std::transform(d.begin(), d.end(), d.begin(), ::tolower);
        for (auto g : gearboxes) {
            std::transform(g.begin(), g.end(), g.begin(), ::tolower);
            if (d == g) return true;
        }
        return false;
    }
};

struct CompositeFilter : IFilterStrategy {
    std::vector<std::shared_ptr<IFilterStrategy>> filters;
    void add(std::shared_ptr<IFilterStrategy> f) { filters.push_back(std::move(f)); }
    bool matches(const Car& car) const override {
        for (const auto& f : filters)
            if (!f->matches(car)) return false;
        return true;
    }
};

// ── Sortowanie (pojedyncze kryterium) ─────────────────────────────────────────
enum class SortField { Price, Year, Mileage, DateAdded };
enum class SortOrder { Asc, Desc };

inline void sortCars(std::vector<Car>& cars, SortField field, SortOrder order) {
    std::stable_sort(cars.begin(), cars.end(),
        [field, order](const Car& a, const Car& b) {
            bool less = false;
            switch (field) {
                case SortField::Price:     less = a.price     < b.price;     break;
                case SortField::Year:      less = a.year      < b.year;      break;
                case SortField::Mileage:   less = a.mileage   < b.mileage;   break;
                case SortField::DateAdded: less = a.id        < b.id;        break;
            }
            return order == SortOrder::Asc ? less : !less;
        });
}
