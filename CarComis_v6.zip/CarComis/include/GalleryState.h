#pragma once
#include "IState.h"
#include "AppContext.h"
#include "UIHelper.h"
#include "FilterStrategy.h"
#include <vector>

class GalleryState : public IState {
public:
    explicit GalleryState(AppContext& ctx);

    void handleEvent(sf::Event& event, StateManager& sm) override;
    void update(float dt, StateManager& sm) override {}
    void render(sf::RenderWindow& window) override;

private:
    AppContext& m_ctx;

    std::vector<Car> m_visible;
    int              m_selected     = -1;
    int              m_scrollOffset = 0;

    // Filtry podstawowe (sidebar)
    UI::InputField m_filterBrand;
    UI::InputField m_filterMinPrice;
    UI::InputField m_filterMaxPrice;
    int            m_focusedField = -1;

    // Sortowanie – jedno aktywne kryterium
    SortField m_sortField = SortField::Price;
    SortOrder m_sortOrder = SortOrder::Asc;
    sf::FloatRect m_btnSort[4];  // Cena | Rok | Przebieg | Data dodania

    // Przyciski sidebar
    sf::FloatRect m_btnApply;
    sf::FloatRect m_btnAdvanced;
    sf::FloatRect m_btnAddCar;
    sf::FloatRect m_btnLogout;
    sf::FloatRect m_btnWatchlist;  // pokazuje tylko obserwowane

    // Layout helpers
    float m_sidebarW    = 160.f;
    float m_filterLabelY = 50.f;
    float m_layoutFontH  = 13.f;
    bool  m_watchlistMode = false;  // true = pokazuj tylko obserwowane

    // ── Modal zaawansowanych filtrow ──────────────────────────────────────────
    bool m_modalOpen = false;

    // Pola tekstowe w modalu
    UI::InputField m_advMinYear;
    UI::InputField m_advMaxYear;
    UI::InputField m_advMinMileage;
    UI::InputField m_advMaxMileage;
    int            m_advFocused = -1;

    // Przyciski wyboru paliwa i nadwozia w modalu
    static const std::vector<std::string> FUEL_OPTIONS;
    static const std::vector<std::string> BODY_OPTIONS;
    static const std::vector<std::string> GEARBOX_OPTIONS;
    int m_advFuel = -1;  // unused
    int m_advBody = -1;  // unused

    std::vector<int> m_advFuels;
    std::vector<int> m_advBodies;
    std::vector<int> m_advGearboxes;

    UI::InputField m_advMinPower;
    UI::InputField m_advMaxPower;
    std::vector<sf::FloatRect> m_modalBtnGearbox;

    std::vector<sf::FloatRect> m_modalBtnFuel;
    std::vector<sf::FloatRect> m_modalBtnBody;
    sf::FloatRect m_modalBtnApply;
    sf::FloatRect m_modalBtnClear;
    sf::FloatRect m_modalBtnClose;
    sf::FloatRect m_modalRect;  // obszar okna modalnego

    bool m_advFiltersActive = false;  // czy jakis adv filtr jest ustawiony

    void recalcLayout();
    void applyFilters();
    void drawSidebar(sf::RenderWindow& window);
    void drawCarGrid(sf::RenderWindow& window);
    void drawModal(sf::RenderWindow& window);
    void handleModalClick(sf::Vector2f mp, StateManager& sm);
    void recalcModal();
    sf::FloatRect cardRect(int i) const;
    void toggleSort(SortField f);

    static constexpr int   COLS = 3;
    static constexpr float GAP  = 8.f;
};
