#pragma once
#include "ICarRepository.h"
#include "FilterStrategy.h"
#include <memory>
#include <vector>
#include <string>

class CarInventory {
public:
    explicit CarInventory(std::shared_ptr<ICarRepository> repo);

    void addCar(const std::string& brand, const std::string& model,
                int year, int mileage, double price,
                const std::string& description, const std::string& imagePath,
                const std::vector<std::string>& extraImages = {},
                const std::string& fuelType = "",
                const std::string& bodyType = "",
                int enginePower = 0,
                const std::string& gearbox = "");
    void updateCar(const Car& car);  // nadpisuje istniejacy rekord po id
    void removeCar(int id);

    std::vector<Car> getAllCars() const;
    std::vector<Car> filter(const IFilterStrategy& strategy) const;
    std::vector<Car> filterAndSort(const IFilterStrategy& strategy,
                                   SortField field, SortOrder order) const;
    bool load();
    bool save() const;

private:
    std::shared_ptr<ICarRepository> m_repo;
};
