#pragma once
#include <string>
#include <vector>

struct Car {
    int         id;
    std::string brand;
    std::string model;
    int         year;
    int         mileage;
    double      price;
    std::string description;
    std::string imagePath;
    std::vector<std::string> extraImages;
    std::string fuelType;   // benzyna | diesel | elektryczny | hybryda
    std::string bodyType;   // sedan | kombi | coupe | suv | hatchback | kabriolet
    int         enginePower = 0;   // KM, 0 = nieznana
    std::string gearbox;    // manualna | automatyczna | p�automatyczna

    Car() : id(0), year(0), mileage(0), price(0.0), enginePower(0) {}

    Car(int id, std::string brand, std::string model,
        int year, int mileage, double price,
        std::string description, std::string imagePath,
        std::vector<std::string> extraImages = {},
        std::string fuelType = "", std::string bodyType = "",
        int enginePower = 0, std::string gearbox = "")
        : id(id), brand(std::move(brand)), model(std::move(model)),
          year(year), mileage(mileage), price(price),
          description(std::move(description)), imagePath(std::move(imagePath)),
          extraImages(std::move(extraImages)),
          fuelType(std::move(fuelType)), bodyType(std::move(bodyType)),
          enginePower(enginePower), gearbox(std::move(gearbox)) {}
};
