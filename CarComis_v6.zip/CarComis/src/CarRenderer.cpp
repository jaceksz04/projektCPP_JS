#include "CarRenderer.h"
#include "UIHelper.h"
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <cmath>

CarRenderer::CarRenderer(sf::Font& font) : m_font(font) {}

sf::Texture& CarRenderer::getTexture(const std::string& path) {
    return getOrLoadTexture(path);
}

sf::Texture& CarRenderer::getOrLoadTexture(const std::string& path) {
    auto it = m_textureCache.find(path);
    if (it != m_textureCache.end()) return it->second;
    sf::Texture tex;
    if (!tex.loadFromFile(path)) {
        sf::Image img;
        img.create(1, 1, sf::Color(80, 80, 90));
        tex.loadFromImage(img);
    }
    m_textureCache[path] = std::move(tex);
    return m_textureCache[path];
}

void CarRenderer::drawPlaceholder(sf::RenderWindow& window, const sf::FloatRect& rect) {
    sf::RectangleShape bg(sf::Vector2f(rect.width, rect.height));
    bg.setPosition(rect.left, rect.top);
    bg.setFillColor(sf::Color(55, 55, 68));
    bg.setOutlineThickness(1.f);
    bg.setOutlineColor(sf::Color(75, 75, 95));
    window.draw(bg);

    unsigned sz = static_cast<unsigned>(std::max(10.f, rect.height * 0.15f));
    sf::Text txt(UI::toSfStr("Brak zdjecia"), m_font, sz);
    txt.setFillColor(sf::Color(140, 140, 155));
    sf::FloatRect tb = txt.getLocalBounds();
    txt.setPosition(rect.left + (rect.width  - tb.width)  * 0.5f - tb.left,
                    rect.top  + (rect.height - tb.height) * 0.5f - tb.top);
    window.draw(txt);
}

// Helper: rysuje obraz w trybie cover (wypelnia caly prostokat, przycina nadmiar)
void CarRenderer::drawImage(sf::RenderWindow& window, const std::string& path,
                             const sf::FloatRect& rect, bool drawBorder) {
    // Ramka
    if (drawBorder) {
        sf::RectangleShape border(sf::Vector2f(rect.width + 2, rect.height + 2));
        border.setPosition(rect.left - 1, rect.top - 1);
        border.setFillColor(sf::Color::Transparent);
        border.setOutlineThickness(1.f);
        border.setOutlineColor(sf::Color(70, 90, 130));
        window.draw(border);
    }
    if (path.empty()) { drawPlaceholder(window, rect); return; }

    sf::Texture& tex = getOrLoadTexture(path);
    float tw = static_cast<float>(tex.getSize().x);
    float th = static_cast<float>(tex.getSize().y);
    if (tw < 1 || th < 1) { drawPlaceholder(window, rect); return; }

    // Cover: skaluj tak zeby obraz wypelnil caly prostokat
    float scale = std::max(rect.width / tw, rect.height / th);
    float sw = tw * scale;
    float sh = th * scale;
    // Wycentruj
    float ox = rect.left + (rect.width  - sw) * 0.5f;
    float oy = rect.top  + (rect.height - sh) * 0.5f;

    sf::Sprite sprite(tex);
    sprite.setScale(scale, scale);
    sprite.setPosition(ox, oy);

    // Uzyj View jako scissor – przytnij do rect
    sf::View oldView = window.getView();
    auto ws = window.getSize();
    sf::View clip;
    clip.setSize(rect.width, rect.height);
    clip.setCenter(rect.left + rect.width * 0.5f, rect.top + rect.height * 0.5f);
    clip.setViewport(sf::FloatRect(
        rect.left   / ws.x, rect.top    / ws.y,
        rect.width  / ws.x, rect.height / ws.y));
    window.setView(clip);
    window.draw(sprite);
    window.setView(oldView);
}

// ── Karta w galerii ───────────────────────────────────────────────────────────
void CarRenderer::drawCard(sf::RenderWindow& window, const Car& car,
                            const sf::FloatRect& bounds, bool selected) {
    sf::RectangleShape bg(sf::Vector2f(bounds.width, bounds.height));
    bg.setPosition(bounds.left, bounds.top);
    bg.setFillColor(selected ? sf::Color(35, 55, 85) : sf::Color(28, 28, 40));
    bg.setOutlineThickness(selected ? 2.f : 1.f);
    bg.setOutlineColor(selected ? sf::Color(80, 150, 230) : sf::Color(55, 55, 78));
    window.draw(bg);

    float imgH = bounds.height * 0.60f;
    sf::FloatRect imgRect(bounds.left + 4, bounds.top + 4,
                          bounds.width - 8, imgH - 4);

    if (!car.imagePath.empty()) {
        sf::Texture& tex = getOrLoadTexture(car.imagePath);
        float tw = static_cast<float>(tex.getSize().x);
        float th = static_cast<float>(tex.getSize().y);
        if (tw > 0 && th > 0) {
            float scale = std::max(imgRect.width / tw, imgRect.height / th);
            float ox = imgRect.left + (imgRect.width  - tw*scale) * 0.5f;
            float oy = imgRect.top  + (imgRect.height - th*scale) * 0.5f;
            sf::Sprite sprite(tex);
            sprite.setScale(scale, scale);
            sprite.setPosition(ox, oy);
            auto ws = window.getSize();
            sf::View oldView = window.getView();
            sf::View clip;
            clip.setSize(imgRect.width, imgRect.height);
            clip.setCenter(imgRect.left + imgRect.width*0.5f, imgRect.top + imgRect.height*0.5f);
            clip.setViewport(sf::FloatRect(
                imgRect.left / ws.x, imgRect.top  / ws.y,
                imgRect.width/ ws.x, imgRect.height/ws.y));
            window.setView(clip);
            window.draw(sprite);
            window.setView(oldView);
        }
    } else {
        drawPlaceholder(window, imgRect);
    }

    float textY  = bounds.top + imgH + 6.f;
    float avail  = bounds.height - imgH - 8.f;
    // Czcionki skalowane do dostepnej wysokosci tekstu
    unsigned nameSz  = static_cast<unsigned>(std::max(10.f, avail * 0.30f));
    unsigned priceSz = static_cast<unsigned>(std::max(9.f,  avail * 0.26f));
    unsigned infoSz  = static_cast<unsigned>(std::max(8.f,  avail * 0.22f));

    auto drawLine = [&](const std::string& s, unsigned sz, sf::Color col, float y) {
        sf::Text t(UI::toSfStr(s), m_font, sz);
        t.setFillColor(col);
        t.setPosition(bounds.left + 6.f, y);
        window.draw(t);
    };

    drawLine(car.brand + " " + car.model, nameSz,  sf::Color(220, 220, 242), textY);
    textY += nameSz + 2.f;

    std::ostringstream ss;
    ss << std::fixed << std::setprecision(0) << car.price << " PLN";
    drawLine(ss.str(), priceSz, sf::Color(70, 200, 110), textY);
    textY += priceSz + 2.f;

    drawLine(std::to_string(car.year) + "  |  " + std::to_string(car.mileage) + " km",
             infoSz, sf::Color(150, 150, 175), textY);

    // Ikona "kliknij 2x" jesli zaznaczone
    if (selected) {
        unsigned hintSz = static_cast<unsigned>(std::max(8.f, avail * 0.20f));
        sf::Text hint(UI::toSfStr("kliknij ponownie aby otworzyc"), m_font, hintSz);
        hint.setFillColor(sf::Color(80, 130, 210));
        sf::FloatRect hb = hint.getLocalBounds();
        hint.setPosition(bounds.left + (bounds.width - hb.width) * 0.5f - hb.left,
                         bounds.top + bounds.height - hintSz - 4.f);
        window.draw(hint);
    }
}

// ── Widok szczegolowy ─────────────────────────────────────────────────────────
void CarRenderer::drawDetail(sf::RenderWindow& window, const Car& car,
                              const sf::FloatRect& bounds) {
    float W = bounds.width;
    float H = bounds.height;
    float x = bounds.left;
    float y = bounds.top;

    float pad = 10.f;

    // Prawa strona: panel informacyjny (od 48% szerokosci)
    float infoX = x + W * 0.48f + pad;
    float infoW = W * 0.52f - 2.f * pad;
    float iy     = y + pad;

    // Tytul (marka + model)
    unsigned titleSz = static_cast<unsigned>(std::max(16.f, H * 0.058f));
    sf::Text title(UI::toSfStr(car.brand + " " + car.model), m_font, titleSz);
    title.setFillColor(sf::Color(220, 225, 255));
    title.setPosition(infoX, iy);
    window.draw(title);
    iy += titleSz + pad * 0.8f;

    // Separator
    sf::RectangleShape sep(sf::Vector2f(infoW * 0.85f, 1.5f));
    sep.setPosition(infoX, iy);
    sep.setFillColor(sf::Color(60, 70, 110));
    window.draw(sep);
    iy += pad * 1.2f;

    // --- Sekcja: Parametry ---
    unsigned secSz   = static_cast<unsigned>(std::max(11.f, H * 0.034f));
    unsigned paramSz = static_cast<unsigned>(std::max(11.f, H * 0.032f));
    float lineGap    = paramSz + static_cast<float>(secSz) * 0.35f;

    sf::Text secParams(UI::toSfStr("Parametry"), m_font, secSz);
    secParams.setFillColor(sf::Color(100, 140, 210));
    secParams.setPosition(infoX, iy);
    window.draw(secParams);
    iy += secSz + 4.f;

    auto drawParam = [&](const std::string& label, const std::string& val) {
        // Etykieta
        sf::Text lbl(UI::toSfStr(label), m_font, paramSz);
        lbl.setFillColor(sf::Color(140, 140, 165));
        lbl.setPosition(infoX + 6.f, iy);
        window.draw(lbl);
        // Wartosc
        sf::Text v(UI::toSfStr(val), m_font, paramSz);
        v.setFillColor(sf::Color(210, 215, 235));
        v.setPosition(infoX + infoW * 0.42f, iy);
        window.draw(v);
        iy += lineGap;
    };

    drawParam("Rok produkcji:", std::to_string(car.year));
    drawParam("Przebieg:",      std::to_string(car.mileage) + " km");

    if (!car.fuelType.empty()) drawParam("Paliwo:",   car.fuelType);
    if (!car.bodyType.empty()) drawParam("Nadwozie:", car.bodyType);
    if (car.enginePower > 0)   drawParam("Moc:",      std::to_string(car.enginePower) + " KM");
    if (!car.gearbox.empty())  drawParam("Skrzynia:", car.gearbox);

    std::ostringstream pss;
    pss << std::fixed << std::setprecision(0) << car.price << " PLN";
    sf::Text priceVal(UI::toSfStr(pss.str()), m_font,
                      static_cast<unsigned>(paramSz * 1.2f));
    priceVal.setFillColor(sf::Color(70, 210, 115));
    sf::Text priceLbl(UI::toSfStr("Cena:"), m_font, paramSz);
    priceLbl.setFillColor(sf::Color(140, 140, 165));
    priceLbl.setPosition(infoX + 6.f, iy);
    window.draw(priceLbl);
    priceVal.setPosition(infoX + infoW * 0.42f, iy);
    window.draw(priceVal);
    iy += paramSz * 1.2f + pad;

    // Separator
    sf::RectangleShape sep2(sf::Vector2f(infoW * 0.85f, 1.f));
    sep2.setPosition(infoX, iy);
    sep2.setFillColor(sf::Color(50, 60, 95));
    window.draw(sep2);
    iy += pad * 1.0f;

    // --- Sekcja: Opis ---
    if (!car.description.empty()) {
        sf::Text secDesc(UI::toSfStr("Opis"), m_font, secSz);
        secDesc.setFillColor(sf::Color(100, 140, 210));
        secDesc.setPosition(infoX, iy);
        window.draw(secDesc);
        iy += secSz + 4.f;

        // Zawijanie opisu do szerokosci infoW * 0.9
        // Szacujemy ~ilosc znakow na linie na podstawie rozmiaru czcionki
        unsigned descSz  = static_cast<unsigned>(std::max(10.f, H * 0.028f));
        int charsPerLine = static_cast<int>(infoW * 0.88f / (descSz * 0.55f));
        if (charsPerLine < 10) charsPerLine = 10;

        std::string desc = car.description;
        float maxDescY   = y + H - pad;
        while (!desc.empty() && iy < maxDescY) {
            size_t cut = std::min<size_t>(desc.size(), (size_t)charsPerLine);
            if (cut < desc.size()) {
                size_t sp = desc.rfind(' ', cut);
                if (sp != std::string::npos && sp > 0) cut = sp;
            }
            sf::Text line(UI::toSfStr(desc.substr(0, cut)), m_font, descSz);
            line.setFillColor(sf::Color(175, 175, 195));
            line.setPosition(infoX + 6.f, iy);
            window.draw(line);
            iy += descSz + 3.f;
            if (cut < desc.size()) desc = desc.substr(cut + 1);
            else desc.clear();
        }
    }
}
