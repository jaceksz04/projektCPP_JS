#include "DetailState.h"
#include "EditAdState.h"
#include "GalleryState.h"
#include <algorithm>

void DetailState::recalcLayout() {
    float W = static_cast<float>(m_ctx.window.getSize().x);
    float H = static_cast<float>(m_ctx.window.getSize().y);
    float btnW = std::max(90.f, W * 0.12f);
    float btnH = std::max(24.f, H * 0.052f);

    m_btnBack   = { W*0.01f, H*0.01f, btnW, btnH };
    m_btnDelete = { W - btnW - W*0.01f, H*0.01f, btnW, btnH };
    m_btnWatch  = { W - btnW - W*0.01f, H*0.01f, btnW, btnH };
    m_btnEdit   = { W - btnW*2.f - W*0.025f, H*0.01f, btnW, btnH };

    // Lightbox
    float lbBtnW = std::max(40.f, W*0.05f);
    float lbBtnH = H*0.15f;
    m_lbBtnPrev  = { 10.f, (H-lbBtnH)*0.5f, lbBtnW, lbBtnH };
    m_lbBtnNext  = { W-lbBtnW-10.f, (H-lbBtnH)*0.5f, lbBtnW, lbBtnH };
    m_lbBtnClose = { W-36.f, 8.f, 28.f, 28.f };
}

void DetailState::handleEvent(sf::Event& event, StateManager& sm) {
    if (event.type == sf::Event::Resized) recalcLayout();

    if (m_lightboxOpen) {
        if (event.type == sf::Event::KeyPressed) {
            if (event.key.code == sf::Keyboard::Escape ||
                event.key.code == sf::Keyboard::Space)
                m_lightboxOpen = false;
            if (event.key.code == sf::Keyboard::Left  && m_lightboxIdx > 0)
                --m_lightboxIdx;
            if (event.key.code == sf::Keyboard::Right &&
                m_lightboxIdx < (int)m_allImages.size()-1)
                ++m_lightboxIdx;
        }
        if (event.type == sf::Event::MouseButtonPressed &&
            event.mouseButton.button == sf::Mouse::Left) {
            sf::Vector2f mp((float)event.mouseButton.x,(float)event.mouseButton.y);
            if (m_lbBtnClose.contains(mp)) { m_lightboxOpen = false; return; }
            if (m_lbBtnPrev.contains(mp) && m_lightboxIdx > 0) { --m_lightboxIdx; return; }
            if (m_lbBtnNext.contains(mp) && m_lightboxIdx < (int)m_allImages.size()-1)
                { ++m_lightboxIdx; return; }
        }
        return;
    }

    if (event.type == sf::Event::MouseButtonPressed &&
        event.mouseButton.button == sf::Mouse::Left) {
        sf::Vector2f mp((float)event.mouseButton.x,(float)event.mouseButton.y);

        if (m_btnBack.contains(mp)) { sm.pop(); return; }

        if (m_btnEdit.contains(mp) && m_ctx.currentUser.isSeller() && !m_deleted) {
            sm.pushDeferred(std::make_shared<EditAdState>(m_ctx, m_car));
            return;
        }
        if (m_btnDelete.contains(mp) && m_ctx.currentUser.isSeller() && !m_deleted) {
            m_ctx.inventory.removeCar(m_car.id);
            m_ctx.inventory.save();
            if (m_ctx.watchlist.contains(m_car.id))
                m_ctx.watchlist.toggle(m_car.id);
            m_deleted = true;
            sm.replaceDeferred(std::make_shared<GalleryState>(m_ctx));
            return;
        }
        if (m_btnWatch.contains(mp) && !m_ctx.currentUser.isSeller() && !m_deleted) {
            m_ctx.watchlist.toggle(m_car.id);
            m_message = m_ctx.watchlist.contains(m_car.id)
                ? "Dodano do obserwowanych!" : "Usunieto z obserwowanych.";
            return;
        }

        // Klik na glowne zdjecie → lightbox
        if (m_mainImgRect.contains(mp) && !m_allImages.empty()) {
            m_lightboxIdx  = m_thumbSelected;
            m_lightboxOpen = true;
            return;
        }
        // Klik na miniaturke
        for (int i = 0; i < (int)m_thumbRects.size(); ++i)
            if (m_thumbRects[i].contains(mp)) { m_thumbSelected = i; return; }

        // Strzalki nawigacji przy miniaturkach
        if (m_btnThumbPrev.contains(mp) && m_thumbSelected > 0)
            { --m_thumbSelected; return; }
        if (m_btnThumbNext.contains(mp) &&
            m_thumbSelected < (int)m_allImages.size()-1)
            { ++m_thumbSelected; return; }
    }

    if (event.type == sf::Event::KeyPressed && !m_lightboxOpen) {
        if (event.key.code == sf::Keyboard::Left  && m_thumbSelected > 0)
            --m_thumbSelected;
        if (event.key.code == sf::Keyboard::Right &&
            m_thumbSelected < (int)m_allImages.size()-1)
            ++m_thumbSelected;
    }
}

// ── Galeria (lewa kolumna) ────────────────────────────────────────────────────
void DetailState::drawGallery(sf::RenderWindow& window) {
    float W  = static_cast<float>(window.getSize().x);
    float H  = static_cast<float>(window.getSize().y);
    auto  mp = sf::Vector2f(sf::Mouse::getPosition(window));

    float topBar    = m_btnBack.top + m_btnBack.height + 8.f;
    float colW      = W * 0.46f;           // szerokosc lewej kolumny
    float pad       = 10.f;

    // ── Główne zdjęcie ────────────────────────────────────────────────────────
    float thumbRowH = std::max(52.f, H * 0.10f);  // wysokosc rzędu miniaturek
    float arrowW    = std::max(24.f, H * 0.045f);
    float mainH     = H - topBar - thumbRowH - 28.f - pad * 3.f;
    mainH           = std::max(mainH, 80.f);

    m_mainImgRect = { pad, topBar, colW - pad, mainH };

    if (!m_allImages.empty()) {
        m_ctx.renderer.drawImage(window, m_allImages[m_thumbSelected],
                                 m_mainImgRect, true);
        // Podpowiedz "kliknij aby powiekszyc"
        unsigned hintSz = (unsigned)std::max(9.f, H * 0.019f);
        sf::Text hint(UI::toSfStr("Kliknij aby powiekszyc  |  strzalki = nawigacja"),
                      m_ctx.font, hintSz);
        hint.setFillColor(sf::Color(70,70,100));
        hint.setPosition(pad, topBar + mainH + 3.f);
        window.draw(hint);
    } else {
        // Placeholder
        sf::RectangleShape ph(sf::Vector2f(m_mainImgRect.width, m_mainImgRect.height));
        ph.setPosition(m_mainImgRect.left, m_mainImgRect.top);
        ph.setFillColor(sf::Color(40,40,55));
        ph.setOutlineThickness(1); ph.setOutlineColor(sf::Color(60,60,80));
        window.draw(ph);
        unsigned phSz = (unsigned)std::max(11.f, H*0.025f);
        sf::Text pt(UI::toSfStr("Brak zdjecia"), m_ctx.font, phSz);
        pt.setFillColor(sf::Color(120,120,140));
        sf::FloatRect pb = pt.getLocalBounds();
        pt.setPosition(pad + (m_mainImgRect.width - pb.width)*0.5f - pb.left,
                       topBar + (mainH - pb.height)*0.5f - pb.top);
        window.draw(pt);
    }

    if (m_allImages.size() <= 1) return;   // tylko 1 zdjęcie – rząd miniaturek zbędny

    // ── Rząd miniaturek ───────────────────────────────────────────────────────
    float thumbY  = topBar + mainH + 20.f;
    float thumbW  = thumbRowH * 1.35f;
    float gap     = 5.f;

    // Ile miniaturek się mieści między strzałkami
    float availW  = colW - pad - arrowW*2.f - gap*2.f;
    int   visible = std::max(1, (int)(availW / (thumbW + gap)));

    // Przesunięcie widoku tak żeby aktywna miniaturka była zawsze widoczna
    if (m_thumbScrollOff > m_thumbSelected) m_thumbScrollOff = m_thumbSelected;
    if (m_thumbScrollOff < m_thumbSelected - visible + 1)
        m_thumbScrollOff = m_thumbSelected - visible + 1;
    m_thumbScrollOff = std::max(0, std::min(m_thumbScrollOff,
                        (int)m_allImages.size() - visible));

    float rowStartX = pad + arrowW + gap;

    // Strzałka lewo
    m_btnThumbPrev = { pad, thumbY, arrowW, thumbRowH };
    bool canPrev = m_thumbSelected > 0;
    sf::RectangleShape aPrev(sf::Vector2f(arrowW, thumbRowH));
    aPrev.setPosition(pad, thumbY);
    aPrev.setFillColor(canPrev
        ? (m_btnThumbPrev.contains(mp) ? sf::Color(60,80,130) : sf::Color(35,40,60))
        : sf::Color(25,25,35));
    aPrev.setOutlineThickness(1);
    aPrev.setOutlineColor(sf::Color(55,55,80));
    window.draw(aPrev);
    if (canPrev) {
        unsigned aSz = (unsigned)std::max(10.f, thumbRowH*0.45f);
        sf::Text at(UI::toSfStr("<"), m_ctx.font, aSz);
        at.setFillColor(sf::Color(200,200,220));
        sf::FloatRect ab = at.getLocalBounds();
        at.setPosition(pad + (arrowW-ab.width)*0.5f - ab.left,
                       thumbY + (thumbRowH-ab.height)*0.5f - ab.top);
        window.draw(at);
    }

    // Strzałka prawo
    float arrowRX = rowStartX + visible*(thumbW+gap) - gap + gap;
    m_btnThumbNext = { arrowRX, thumbY, arrowW, thumbRowH };
    bool canNext = m_thumbSelected < (int)m_allImages.size()-1;
    sf::RectangleShape aNext(sf::Vector2f(arrowW, thumbRowH));
    aNext.setPosition(arrowRX, thumbY);
    aNext.setFillColor(canNext
        ? (m_btnThumbNext.contains(mp) ? sf::Color(60,80,130) : sf::Color(35,40,60))
        : sf::Color(25,25,35));
    aNext.setOutlineThickness(1);
    aNext.setOutlineColor(sf::Color(55,55,80));
    window.draw(aNext);
    if (canNext) {
        unsigned aSz = (unsigned)std::max(10.f, thumbRowH*0.45f);
        sf::Text at(UI::toSfStr(">"), m_ctx.font, aSz);
        at.setFillColor(sf::Color(200,200,220));
        sf::FloatRect ab = at.getLocalBounds();
        at.setPosition(arrowRX + (arrowW-ab.width)*0.5f - ab.left,
                       thumbY + (thumbRowH-ab.height)*0.5f - ab.top);
        window.draw(at);
    }

    // Miniaturki
    m_thumbRects.resize(m_allImages.size());
    for (int i = 0; i < (int)m_allImages.size(); ++i)
        m_thumbRects[i] = { -999.f, -999.f, 0.f, 0.f }; // domyslnie poza ekranem

    for (int vi = 0; vi < visible; ++vi) {
        int i = vi + m_thumbScrollOff;
        if (i >= (int)m_allImages.size()) break;

        float tx = rowStartX + vi*(thumbW+gap);
        sf::FloatRect tr(tx, thumbY, thumbW, thumbRowH);
        m_thumbRects[i] = tr;

        bool active  = (i == m_thumbSelected);
        bool hovered = tr.contains(mp);

        // Ramka
        sf::RectangleShape frame(sf::Vector2f(tr.width+4, tr.height+4));
        frame.setPosition(tr.left-2, tr.top-2);
        frame.setFillColor(sf::Color::Transparent);
        frame.setOutlineThickness(active ? 2.f : 1.f);
        frame.setOutlineColor(active ? sf::Color(80,160,255)
                            : (hovered ? sf::Color(110,130,170) : sf::Color(50,50,75)));
        window.draw(frame);

        m_ctx.renderer.drawImage(window, m_allImages[i], tr, false);

        // Numer
        unsigned numSz = (unsigned)std::max(8.f, thumbRowH*0.22f);
        sf::Text num(UI::toSfStr(std::to_string(i+1)), m_ctx.font, numSz);
        num.setFillColor(active ? sf::Color(255,255,255) : sf::Color(160,160,185));
        num.setPosition(tx+3.f, thumbY + thumbRowH - numSz - 2.f);
        window.draw(num);
    }

    // Licznik
    unsigned cntSz = (unsigned)std::max(9.f, H*0.020f);
    sf::Text cnt(UI::toSfStr(std::to_string(m_thumbSelected+1) + "/" +
                             std::to_string(m_allImages.size())),
                 m_ctx.font, cntSz);
    cnt.setFillColor(sf::Color(100,100,130));
    cnt.setPosition(pad, thumbY + thumbRowH + 3.f);
    window.draw(cnt);
}

// ── Lightbox ──────────────────────────────────────────────────────────────────
void DetailState::drawLightbox(sf::RenderWindow& window) {
    float W = static_cast<float>(window.getSize().x);
    float H = static_cast<float>(window.getSize().y);
    auto  mp = sf::Vector2f(sf::Mouse::getPosition(window));

    sf::RectangleShape bg(sf::Vector2f(W,H));
    bg.setFillColor(sf::Color(0,0,0,235));
    window.draw(bg);

    if (m_lightboxIdx < (int)m_allImages.size()) {
        float pad = 64.f;
        sf::Texture& tex = m_ctx.renderer.getTexture(m_allImages[m_lightboxIdx]);
        float tw = (float)tex.getSize().x, th = (float)tex.getSize().y;
        if (tw > 0 && th > 0) {
            float availW = W - pad*2.f, availH = H - pad*2.f;
            float scale  = std::min(availW/tw, availH/th);
            sf::Sprite sp(tex);
            sp.setScale(scale, scale);
            sp.setPosition((W - tw*scale)*0.5f, (H - th*scale)*0.5f);
            window.draw(sp);
        }
    }

    // Licznik
    unsigned cntSz = (unsigned)std::max(12.f, H*0.028f);
    sf::Text cnt(UI::toSfStr(std::to_string(m_lightboxIdx+1) + " / " +
                             std::to_string(m_allImages.size())),
                 m_ctx.font, cntSz);
    cnt.setFillColor(sf::Color(210,210,230));
    sf::FloatRect cb = cnt.getLocalBounds();
    cnt.setPosition(W*0.5f - cb.width*0.5f - cb.left, 12.f);
    window.draw(cnt);

    if (m_lightboxIdx > 0)
        UI::drawButton(window, m_ctx.font, m_lbBtnPrev, "<", m_lbBtnPrev.contains(mp));
    if (m_lightboxIdx < (int)m_allImages.size()-1)
        UI::drawButton(window, m_ctx.font, m_lbBtnNext, ">", m_lbBtnNext.contains(mp));

    // X
    sf::RectangleShape xbg(sf::Vector2f(28,28));
    xbg.setPosition(m_lbBtnClose.left, m_lbBtnClose.top);
    xbg.setFillColor(m_lbBtnClose.contains(mp) ? sf::Color(180,50,50):sf::Color(90,40,40));
    window.draw(xbg);
    sf::Text xt(UI::toSfStr("X"), m_ctx.font, 14);
    xt.setFillColor(sf::Color(230,200,200));
    sf::FloatRect xb = xt.getLocalBounds();
    xt.setPosition(m_lbBtnClose.left+(28-xb.width)*0.5f-xb.left,
                   m_lbBtnClose.top+(28-xb.height)*0.5f-xb.top);
    window.draw(xt);

    unsigned hintSz = (unsigned)std::max(9.f, H*0.019f);
    sf::Text hint(UI::toSfStr("Strzalki  |  Spacja / Esc = zamknij"),
                  m_ctx.font, hintSz);
    hint.setFillColor(sf::Color(70,70,100));
    sf::FloatRect hb = hint.getLocalBounds();
    hint.setPosition(W*0.5f-hb.width*0.5f-hb.left, H-hintSz-8.f);
    window.draw(hint);
}

// ── Render ────────────────────────────────────────────────────────────────────
void DetailState::render(sf::RenderWindow& window) {
    recalcLayout();
    window.clear(sf::Color(15, 15, 25));

    float W  = static_cast<float>(window.getSize().x);
    float H  = static_cast<float>(window.getSize().y);
    float topBar = m_btnBack.top + m_btnBack.height + 8.f;

    // Panel informacyjny (prawa kolumna) – drawDetail nie rysuje juz zdjec
    m_ctx.renderer.drawDetail(window, m_car,
        sf::FloatRect(0, topBar, W, H - topBar - H*0.04f));

    // Galeria (lewa kolumna)
    drawGallery(window);

    // Przyciski gornego paska
    auto mp = sf::Vector2f(sf::Mouse::getPosition(window));
    UI::drawButton(window, m_ctx.font, m_btnBack, "< Wróc", m_btnBack.contains(mp));

    if (m_ctx.currentUser.isSeller() && !m_deleted) {
        UI::drawButton(window, m_ctx.font, m_btnEdit,   "Edytuj",  m_btnEdit.contains(mp));
        UI::drawButton(window, m_ctx.font, m_btnDelete, "Usun",    m_btnDelete.contains(mp));
    }

    if (!m_ctx.currentUser.isSeller() && !m_deleted) {
        bool watching = m_ctx.watchlist.contains(m_car.id);
        sf::FloatRect r = m_btnWatch;
        sf::RectangleShape bg(sf::Vector2f(r.width, r.height));
        bg.setPosition(r.left, r.top);
        bg.setFillColor(watching ? sf::Color(140,100,10)
                       : (r.contains(mp) ? sf::Color(50,60,90) : sf::Color(40,45,65)));
        bg.setOutlineThickness(watching ? 2.f : 1.f);
        bg.setOutlineColor(watching ? sf::Color(230,180,40) : sf::Color(80,80,110));
        window.draw(bg);
        unsigned wsz = (unsigned)std::max(10.f, r.height*0.42f);
        sf::Text wt(UI::toSfStr(watching ? "* Obserwujesz" : "* Obserwuj"),
                    m_ctx.font, wsz);
        wt.setFillColor(watching ? sf::Color(255,220,80) : sf::Color(220,220,240));
        sf::FloatRect wb = wt.getLocalBounds();
        wt.setPosition(r.left+(r.width-wb.width)*0.5f-wb.left,
                       r.top+(r.height-wb.height)*0.5f-wb.top);
        window.draw(wt);
    }

    if (!m_message.empty()) {
        unsigned msgSz = (unsigned)std::max(12.f, H*0.028f);
        sf::Text msg(UI::toSfStr(m_message), m_ctx.font, msgSz);
        msg.setFillColor(sf::Color(80,220,100));
        msg.setPosition(10, H - msgSz - 8.f);
        window.draw(msg);
    }

    if (m_lightboxOpen) drawLightbox(window);
}
